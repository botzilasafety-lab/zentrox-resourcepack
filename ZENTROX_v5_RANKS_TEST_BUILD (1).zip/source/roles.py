"""ZENTROX — макеты: хаб /rank и меню групп PLAYER(default), YOUTUBE, GL_ADMIN.
Та же дизайн-система, что v4 B+ и меню донатов. Данные — только подтверждённые."""
import math, random
from PIL import Image, ImageDraw
from pix import *
import ranks
from ranks import (BG, PANEL, PANEL2, LINE, LINE2, VIOD, VIO, VIO2, WHITE, DIM, DIM2, mix, badge, glow, ic, vgrad, bevel, rect)

# цвета — из оригинальных плашек
ranks.THEME.update({
 'default':  dict(acc='c8cad9', lit='f9f9fc', drk='484c62', tag='БАЗОВЫЙ РАНГ'),
 'youtube':  dict(acc='ff7188', lit='ffd3dc', drk='852d49', tag='АВТОР КОНТЕНТА'),
 'gl_admin': dict(acc='fb8d61', lit='ffd2bd', drk='581722', tag='ГЛАВНЫЙ АДМИН'),
 'st_admin': dict(acc='fc5663', lit='ffc0c6', drk='631d32', tag=''),
 'admin':    dict(acc='fa6962', lit='ffc4c0', drk='5f1a29', tag=''),
 'ml_admin': dict(acc='fa97ca', lit='ffd6ec', drk='752955', tag=''),
 'tester':   dict(acc='b4ef79', lit='e2ffc8', drk='4b7227', tag=''),
})
T = ranks.T
WEIGHT = {'gl_admin': 100, 'st_admin': 99, 'admin': 98, 'ml_admin': 97, 'default': 0, 'tester': 0, 'youtube': 0}

def base(rank):
    img = Image.new('RGBA', (W, H), BG); ranks.bg_motif(img, 'phantom' if rank == 'hub' else 'blaze') if False else None
    acc, lit, drk = T(rank) if rank != 'hub' else (VIO2, hexc('d8b8ff'), VIOD)
    px = img.load()
    for y in range(H):
        for x in range(W):
            v = (abs(x - W / 2) / (W / 2)) ** 2 * .3 + (y / 125) ** 2 * .2
            px[x, y] = mix(hexc('0d0a15'), BG, min(.9, v))
    for y in range(0, 125):
        for x in range(W):
            dv = math.hypot((x - 120) / 90, (y - 40) / 50)
            if dv < 1: px[x, y] = mix(px[x, y], hexc('1e0f36'), (1 - dv) * .5)
            dr = math.hypot((x - 30) / 60, (y - 70) / 60)
            if dr < 1: px[x, y] = mix(px[x, y], drk, (1 - dr) * .3)
    rect(img, (0, 0, W - 1, H - 1), outline=VIOD); rect(img, (1, 1, W - 2, H - 2), outline=hexc('17112a'))
    for (x, y) in [(0, 0), (W - 1, 0), (0, H - 1), (W - 1, H - 1)]: px[x, y] = (0, 0, 0, 0)
    return img

def footer(img, crumbs, back=True):
    d = ImageDraw.Draw(img)
    d.line([(26, 125), (149, 125)], fill=LINE)
    if back:
        x, y = slot_xy(45); r = (x + 1, y + 1, x + 16, y + 16)
        vgrad(img, r, hexc('231a3a'), hexc('150f24')); bevel(img, r, LINE2, hexc('07060b')); arrow_left(img, x + 5, y + 6, hexc('d8b8ff'))
    x, y = slot_xy(53); r = (x + 1, y + 1, x + 16, y + 16)
    vgrad(img, r, hexc('231a3a'), hexc('150f24')); bevel(img, r, hexc('7a3a52'), hexc('07060b')); cross(img, x + 6, y + 6, hexc('ff6b81'))
    # breadcrumb (slots 46-52, decorative)
    y0 = slot_xy(46)[1] + 6
    parts = []
    for i, c in enumerate(crumbs):
        parts.append((c, WHITE if i == len(crumbs) - 1 else DIM2))
    total = sum(text_w(c) for c, _ in parts) + (len(parts) - 1) * 9
    if total > 112 and len(parts) > 2:
        parts = parts[1:]; total = sum(text_w(c) for c, _ in parts) + (len(parts) - 1) * 9
    x = 88 - total // 2
    for i, (c, col) in enumerate(parts):
        text(img, x, y0, c, col); x += text_w(c)
        if i < len(parts) - 1: text(img, x + 3, y0, '>', LINE2); x += 9
    rect(img, (2, 126, W - 3, H - 3), fill=hexc('0c0914')); d.line([(7, 126), (168, 126)], fill=LINE)
    player_inv(img, BG, hexc('120e1c'), LINE2, hexc('050408'))

def info_plate(img, rank, label, value, scale=2):
    acc, lit, drk = T(rank); pr = (114, 4, 168, 32)
    vgrad(img, pr, hexc('1c1433'), hexc('100b1d')); rframe(img, pr, rank)
    text_c(img, (pr[0] + pr[2]) // 2, 7, label, DIM)
    text_c(img, (pr[0] + pr[2]) // 2 + 1, 16 if scale == 2 else 19, value, lit, scale=scale, shadow=drk)

def header(img, rank):
    acc, lit, drk = T(rank); b = badge(rank)
    glow(img, (9, 6, 9 + b.width - 1, 6 + b.height - 1), acc, 4, .35)
    img.alpha_composite(b, (9, 6))
    text(img, 9, 24, ranks.THEME[rank]['tag'], mix(acc, WHITE, .35))

# ---------- frames for new groups ----------
def rframe(img, r, rank):
    acc, lit, drk = T(rank); x0, y0, x1, y1 = r; d = ImageDraw.Draw(img); px = img.load()
    if rank == 'default':
        bevel(img, r, hexc('8a8ca0'), hexc('2a2b36'))
    elif rank == 'youtube':
        rect(img, r, outline=mix(acc, BG, .35)); d.line([(x0 + 1, y0), (x1 - 1, y0)], fill=acc); d.line([(x0 + 1, y0 + 1), (x1 - 1, y0 + 1)], fill=drk)
        for (x, y) in ((x0, y0), (x1, y0), (x0, y1), (x1, y1)): px[x, y] = BG  # rounded look
    elif rank == 'gl_admin':
        rect(img, r, outline=drk); rect(img, (x0 + 1, y0 + 1, x1 - 1, y1 - 1), outline=acc)
        for (x, y) in ((x0 + 1, y0 + 1), (x1 - 1, y0 + 1), (x0 + 1, y1 - 1), (x1 - 1, y1 - 1)):
            rect(img, (x - 1, y - 1, x + 1, y + 1), fill=lit); px[x, y] = drk  # rivets
    elif rank == 'hub':
        bevel(img, r, VIO2, VIOD)
    else:
        ranks.frame(img, r, rank)

# ---------- emblems ----------
def art_default(img, r):
    x0, y0, x1, y1 = r; cx = (x0 + x1) // 2; px = img.load(); rnd = random.Random(3)
    vgrad(img, r, hexc('0e1020'), hexc('1d2238'))
    for _ in range(30): px[rnd.randint(x0, x1), rnd.randint(y0, y0 + 30)] = mix(BG, WHITE, rnd.choice([.2, .4]))
    # isometric grass block, cube edge 14
    s = 14; top = y0 + 22
    for i in range(s):
        for j in range(s):
            X = cx + (i - j) * 1; Y = top + (i + j) // 2
            for dx in (0, 1):
                px[X + dx - 1, Y] = hexc('74cf4e') if (i * 7 + j * 3) % 5 else hexc('5fb83a')
    for k in range(s):  # left face
        for h in range(s + 2):
            X = cx - s + k; Y = top + s // 2 + k // 2 + h
            if x0 <= X <= x1: px[X, Y] = (hexc('4e9a30') if h < 3 else (hexc('6b4426') if (k + h) % 4 else hexc('5a3a22')))
    for k in range(s):  # right face
        for h in range(s + 2):
            X = cx + k; Y = top + s - 1 - k // 2 + h - s // 2 + s // 2
            Y = top + s // 2 + (s - 1 - k) // 2 + h
            if x0 <= X <= x1: px[X, Y] = (hexc('3f7f27') if h < 3 else (hexc('55361e') if (k + h) % 4 else hexc('47301c')))
    # small sword stuck next to it
    for k in range(12): px[cx + 12 - k // 3, y1 - 16 - k] = hexc('e2e4ea')
    rect(img, (cx + 8, y1 - 17, cx + 14, y1 - 16), fill=hexc('8a6a3a')); rect(img, (cx + 10, y1 - 15, cx + 11, y1 - 12), fill=hexc('6b4426'))
    for y in range(y1 - 8, y1 + 1):
        for x in range(x0, x1 + 1): px[x, y] = hexc('2a2b36') if (x + y) % 6 else hexc('353646')

def art_youtube(img, r):
    x0, y0, x1, y1 = r; cx = (x0 + x1) // 2; px = img.load(); rnd = random.Random(9); d = ImageDraw.Draw(img)
    vgrad(img, r, hexc('1a0a16'), hexc('3a1230'))
    for _ in range(22): px[rnd.randint(x0, x1), rnd.randint(y0, y1)] = mix(BG, hexc('ffd3dc'), rnd.choice([.3, .6]))
    # screen
    sx0, sy0, sx1, sy1 = x0 + 5, y0 + 14, x1 - 5, y0 + 44
    rect(img, (sx0, sy0, sx1, sy1), fill=hexc('140a14'), outline=hexc('ff7188'))
    rect(img, (sx0 + 1, sy0 + 1, sx1 - 1, sy0 + 3), fill=hexc('852d49'))
    # play button
    bx0, by0, bx1, by1 = cx - 11, sy0 + 8, cx + 11, sy0 + 24
    rect(img, (bx0, by0, bx1, by1), fill=hexc('ff3355')); rect(img, (bx0 + 1, by0, bx1 - 1, by0), fill=hexc('ff7188'))
    for (x, y) in ((bx0, by0), (bx1, by0), (bx0, by1), (bx1, by1)): px[x, y] = hexc('140a14')
    for k in range(7): d.line([(cx - 3 + k, by0 + 4 + k // 2), (cx - 3 + k, by1 - 4 - k // 2)], fill=WHITE)
    # stand
    rect(img, (cx - 2, sy1 + 1, cx + 2, sy1 + 4), fill=hexc('852d49')); rect(img, (cx - 9, sy1 + 5, cx + 9, sy1 + 6), fill=hexc('852d49'))
    # REC dot + progress bar
    rect(img, (sx0 + 3, sy0 + 5, sx0 + 4, sy0 + 6), fill=hexc('ff3355'))
    d.line([(sx0 + 3, sy1 - 3), (sx1 - 3, sy1 - 3)], fill=hexc('3a1a2a')); d.line([(sx0 + 3, sy1 - 3), (sx0 + 22, sy1 - 3)], fill=hexc('ff7188'))
    # camera at bottom
    cy = y1 - 14
    rect(img, (cx - 10, cy, cx + 6, cy + 9), fill=hexc('2a1a2e'), outline=hexc('ff7188'))
    d.polygon([(cx + 7, cy + 2), (cx + 12, cy - 1), (cx + 12, cy + 10), (cx + 7, cy + 7)], fill=hexc('852d49'))
    rect(img, (cx - 4, cy + 3, cx - 1, cy + 6), fill=hexc('ff3355'))

def art_gl_admin(img, r):
    x0, y0, x1, y1 = r; cx = (x0 + x1) // 2; px = img.load(); d = ImageDraw.Draw(img); rnd = random.Random(4)
    vgrad(img, r, hexc('1a0a0c'), hexc('3a1418'))
    # banners left/right
    for bx in (x0 + 4, x1 - 10):
        rect(img, (bx, y0 + 4, bx + 6, y0 + 40), fill=hexc('581722'))
        d.polygon([(bx, y0 + 40), (bx + 6, y0 + 40), (bx + 3, y0 + 44)], fill=hexc('581722'))
        rect(img, (bx + 2, y0 + 10, bx + 4, y0 + 12), fill=hexc('fb8d61'))
        d.line([(bx - 1, y0 + 4), (bx + 7, y0 + 4)], fill=hexc('ffd2bd'))
    # shield
    sx0, sx1, sy0 = cx - 15, cx + 15, y0 + 18
    for y in range(sy0, sy0 + 40):
        t = (y - sy0) / 40
        hw = 15 if t < .55 else int(15 * (1 - (t - .55) / .45) ** .8)
        for x in range(cx - hw, cx + hw + 1):
            edge = abs(x - cx) >= hw - 1 or y == sy0
            px[x, y] = hexc('fb8d61') if edge else (hexc('7a2030') if x < cx else hexc('5f1826'))
    # Z monogram
    zx, zy = cx - 6, sy0 + 9
    sprite(img, zx, zy, ["############", "############", ".........##.", "........##..", ".......##...", "......##....", ".....##.....", "....##......", "...##.......", "..##........", "############", "############"],
           {'#': hexc('ffd2bd')})
    # crown above
    sprite(img, cx - 9, sy0 - 11, ["..W.....W.....W..", "..Y.....Y.....Y..", "..YY...YYY...YY..", "..YYY.YYYYY.YYY..", "..YYYYYYYYYYYYY..", "..OOOOOOOOOOOOO.."],
           {'W': hexc('ffffff'), 'Y': hexc('fb8d61'), 'O': hexc('a8442c')})
    glow(img, (cx - 15, sy0, cx + 15, sy0 + 38), hexc('fb8d61'), 3, .25)
    for _ in range(14): px[rnd.randint(x0, x1), rnd.randint(y0 + 40, y1)] = hexc('fb8d61')
    for y in range(y1 - 6, y1 + 1):
        for x in range(x0, x1 + 1): px[x, y] = hexc('241016')

ART = {'default': art_default, 'youtube': art_youtube, 'gl_admin': art_gl_admin}

def emblem(img, rank):
    acc, lit, drk = T(rank); er = (8, 36, 59, 105)
    glow(img, er, acc, 4, .35)
    ART[rank](img, (er[0] + 2, er[1] + 2, er[2] - 2, er[3] - 2))
    rframe(img, er, rank)

def bar(img, row, rank, icon, label, right=None, right_scale=1, active=False, cols=(3, 8)):
    acc, lit, drk = T(rank)
    x0, y0, x1, y1 = area(cols[0], row, cols[1], row); r = (x0 + 2, y0 + 1, x1 - 1, y1 - 1)
    vgrad(img, r, mix(PANEL2, drk, .45 if active else .25), PANEL); rframe(img, r, rank)
    if icon: ic(img, r[0] + 4, r[1] + 3, icon, acc)
    text(img, r[0] + (18 if icon else 6), r[1] + 5, label, WHITE if active else DIM)
    if right:
        text(img, r[2] - 4 - text_w(right, right_scale), r[1] + (1 if right_scale == 2 else 5), right, lit, scale=right_scale, shadow=drk if right_scale == 2 else None)
    return r

ranks.IC['info'] = ["....###....", "...#...#...", "..#..#..#..", "..#.....#..", "..#..#..#..", "..#..#..#..", "..#..#..#..", "...#...#...", "....###....", "...........", "..........."]
ranks.IC['send'] = ["..........#", "........##.", "......##.#.", "....##...#.", "..##....#..", "####...#...", "....#.#....", ".....##....", ".....#.....", "...........", "..........."]
ranks.IC['up'] = ["....#......", "...###.....", "..#####....", ".#######...", "...###.....", "...###.....", "...###.....", "...###.....", "...###.....", "...........", "..........."]

# ---------- PLAYER (default) ----------
def build_default():
    rank = 'default'; img = base(rank); header(img, rank)
    info_plate(img, rank, 'ЦЕНА', 'БЕСПЛАТНО', scale=1)
    emblem(img, rank)
    D = ranks.DATA['player']
    bar(img, 1, rank, 'auc', 'АУКЦИОН', str(D['auc']), 2)
    bar(img, 2, rank, 'prv', 'ПРИВАТЫ', str(D['prv']), 2)
    bar(img, 3, rank, 'home', 'ДОМА', str(D['home']), 2)
    # action: to donate category
    x0, y0, x1, y1 = area(3, 4, 8, 4); r = (x0 + 2, y0 + 1, x1 - 1, y1 - 1)
    glow(img, r, VIO2, 3, .4); vgrad(img, r, hexc('9b5cf6'), hexc('6d28d9')); rect(img, r, outline=hexc('d8b8ff'))
    ic(img, r[0] + 4, r[1] + 3, 'up', WHITE); text(img, r[0] + 18, r[1] + 5, 'УЛУЧШИТЬ РАНГ', WHITE, shadow=VIOD); text(img, r[2] - 4 - text_w('>'), r[1] + 5, '>', WHITE)
    footer(img, ['РАНГИ', 'ИГРОКИ', 'PLAYER'])
    return img, {'Цена (инфо)': [6, 7, 8], 'Эмблема: описание роли': slots_in(0, 1, 2, 4), 'Аукцион': slots_in(3, 1, 8, 1),
                 'Приваты': slots_in(3, 2, 8, 2), 'Дома': slots_in(3, 3, 8, 3), 'Улучшить → меню донатов': slots_in(3, 4, 8, 4),
                 'Назад → категория Игроки': [45], 'Закрыть': [53]}

# ---------- YOUTUBE ----------
def build_youtube():
    rank = 'youtube'; img = base(rank); header(img, rank)
    info_plate(img, rank, 'ВЕС', '0')
    emblem(img, rank)
    acc, lit, drk = T(rank)
    # role panel rows 1-2
    x0, y0, _, _ = area(3, 1, 8, 1); _, _, x1, y1 = area(3, 2, 8, 2); r = (x0 + 2, y0 + 1, x1 - 1, y1 - 1)
    vgrad(img, r, mix(PANEL2, drk, .4), PANEL); rframe(img, r, rank)
    text(img, r[0] + 6, r[1] + 5, 'РОЛЬ', DIM)
    text(img, r[0] + 6, r[1] + 15, 'АВТОР', lit, scale=2, shadow=drk)
    text(img, r[0] + 6 + text_w('АВТОР', 2) + 6, r[1] + 22, 'КОНТЕНТА', lit, shadow=drk)
    bar(img, 3, rank, 'info', 'УСЛОВИЯ ПОЛУЧЕНИЯ', '?')
    bar(img, 4, rank, 'send', 'СВЯЗЬ', 'TELEGRAM')
    footer(img, ['РАНГИ', 'ИГРОКИ', 'YOUTUBE'])
    return img, {'Вес (инфо)': [6, 7, 8], 'Эмблема: описание роли': slots_in(0, 1, 2, 4), 'Роль': slots_in(3, 1, 8, 2),
                 'Условия (текст от владельца)': slots_in(3, 3, 8, 3), 'Связь (контакт от владельца)': slots_in(3, 4, 8, 4),
                 'Назад → категория Игроки': [45], 'Закрыть': [53]}

# ---------- GL_ADMIN ----------
def build_gl_admin():
    rank = 'gl_admin'; img = base(rank); header(img, rank)
    info_plate(img, rank, 'ВЕС', '100')
    emblem(img, rank)
    branch = ['gl_admin', 'st_admin', 'admin', 'ml_admin']
    for i, g in enumerate(branch):
        acc, lit, drk = T(g); cur = g == rank
        x0, y0, x1, y1 = area(3, 1 + i, 8, 1 + i); r = (x0 + 2, y0 + 1, x1 - 1, y1 - 1)
        if cur: glow(img, r, T(rank)[0], 3, .45)
        vgrad(img, r, mix(PANEL2, drk, .55 if cur else .2), PANEL); rframe(img, r, rank if cur else 'default')
        if not cur:
            rect(img, r, outline=mix(acc, BG, .6))
        b = badge(g)
        if not cur:
            b = b.copy(); px = b.load()
            for yy in range(b.height):
                for xx in range(b.width):
                    p = px[xx, yy]
                    if p[3]: px[xx, yy] = tuple(int(c * .6 + 20) for c in p[:3]) + (p[3],)
        img.alpha_composite(b, (r[0] + 3, r[1] + 1))
        ws = str(WEIGHT[g]); text(img, r[2] - 4 - text_w(ws), r[1] + 5, ws, lit if cur else DIM2)
    footer(img, ['РАНГИ', 'ПЕРСОНАЛ', 'GL.ADMIN'])
    return img, {'Вес (инфо)': [6, 7, 8], 'Эмблема: описание роли': slots_in(0, 1, 2, 4),
                 'Ветка: GL.ADMIN (текущий)': slots_in(3, 1, 8, 1), 'Ветка: ST.ADMIN → меню': slots_in(3, 2, 8, 2),
                 'Ветка: ADMIN → меню': slots_in(3, 3, 8, 3), 'Ветка: ML.ADMIN → меню': slots_in(3, 4, 8, 4),
                 'Назад → категория Персонал': [45], 'Закрыть': [53]}

# ---------- HUB /rank ----------
def hub_card(img, c0, c1, title, sub, icon_fn, accent, hero=False):
    x0, y0, x1, y1 = area(c0, 1, c1, 3); r = (x0 + 2, y0 + 2, x1 - 2, y1 - 1)
    glow(img, r, accent, 5 if hero else 3, .55 if hero else .3)
    vgrad(img, r, mix(PANEL2, accent, .18 if hero else .1), PANEL)
    bevel(img, r, mix(accent, WHITE, .3), mix(accent, BG, .55)); bevel(img, (r[0] + 1, r[1] + 1, r[2] - 1, r[3] - 1), mix(accent, BG, .5), BG)
    if hero: ranks_gem(img, (r[0] + r[2]) // 2, r[1], accent)
    cx = (r[0] + r[2]) // 2
    icon_fn(img, cx, r[1] + 18)
    text_c(img, cx, r[3] - 20, title, WHITE, shadow=BG)
    text_c(img, cx, r[3] - 10, sub, mix(accent, WHITE, .3))

def ranks_gem(img, cx, cy, col):
    d = ImageDraw.Draw(img)
    for k in range(3):
        d.line([(cx - k, cy - 2 + k), (cx + k, cy - 2 + k)], fill=WHITE if k == 0 else col); d.line([(cx - k, cy + 2 - k), (cx + k, cy + 2 - k)], fill=col)

def icon_players(img, cx, cy):
    for i, g in enumerate(['default', 'tester', 'youtube']):
        b = badge(g); x = cx - 38 + i * 2; y = cy - 12 + i * 9
    # three stacked mini badges look cluttered -> one big person glyph
    sprite(img, cx - 14, cy - 14, ["....######....", "....#WWWW#....", "....#WEEW#....", "....#WWWW#....", "....######....", "..##########..", ".#WWWWWWWWWW#.", ".#WWWWWWWWWW#.", ".#WW#WWWW#WW#.", ".#WW#WWWW#WW#.", "..##.#WW#.##..", ".....#WW#.....", ".....#WW#.....", ".....####....."],
           {'#': hexc('484c62'), 'W': hexc('c8cad9'), 'E': hexc('14131e')}, 2)

def icon_donate(img, cx, cy):
    sprite(img, cx - 13, cy - 10, ranks.CROWN, {'W': hexc('fffbe8'), 'Y': hexc('ffcf4a'), 'O': hexc('b8860b'), 'R': hexc('a855f7'), 'V': hexc('7c3aed')})
    for i, g in enumerate(['blaze', 'astra', 'inferno', 'phantom', 'nexus', 'zenith']):
        acc = T(g)[0]; x = cx - 13 + i * 5; rect(img, (x, cy + 4, x + 3, cy + 7), fill=acc)

def icon_staff(img, cx, cy):
    d = ImageDraw.Draw(img); px = img.load(); sy0 = cy - 11
    for y in range(sy0, sy0 + 22):
        t = (y - sy0) / 22; hw = 9 if t < .5 else int(9 * (1 - (t - .5) / .5) ** .8)
        for x in range(cx - hw, cx + hw + 1):
            px[x, y] = hexc('fb8d61') if abs(x - cx) >= hw - 1 or y == sy0 else (hexc('3c286c') if x < cx else hexc('2a1d4f'))
    for i, g in enumerate(['gl_admin', 'gl_moder', 'helper']):
        rect(img, (cx - 5 + i * 4, sy0 + 6, cx - 3 + i * 4, sy0 + 12), fill=T(g)[0] if g in ranks.THEME else hexc('80efc7'))

def build_hub():
    img = base('hub'); d = ImageDraw.Draw(img)
    hp = (6, 3, W - 7, 28); vgrad(img, hp, hexc('1c1433'), hexc('100b1d')); rect(img, hp, outline=LINE2)
    text(img, 13, 8, 'ZENTROX', WHITE, scale=2, sp=1, shadow=VIO)
    s = 'РАНГИ И ГРУППЫ'; text(img, W - 13 - text_w(s), 12, s, DIM)
    d.line([(13, 25), (88, 25)], fill=VIO2); d.line([(89, 25), (W - 14, 25)], fill=LINE)
    ranks.THEME.setdefault('helper', dict(acc='80efc7', lit='d0ffef', drk='1d6050', tag=''))
    ranks.THEME.setdefault('gl_moder', dict(acc='b399fd', lit='e4dbff', drk='3c286c', tag=''))
    hub_card(img, 0, 2, 'ИГРОКИ', '3 ГРУППЫ', icon_players, hexc('c8cad9'))
    hub_card(img, 3, 5, 'ДОНАТЫ', '6 РАНГОВ', icon_donate, hexc('ffcf4a'), hero=True)
    hub_card(img, 6, 8, 'ПЕРСОНАЛ', '11 ГРУПП', icon_staff, hexc('b399fd'))
    # "Твой ранг" bar cols 1-7 row 4
    x0, y0, x1, y1 = area(1, 4, 7, 4); r = (x0 + 2, y0 + 1, x1 - 2, y1 - 1)
    glow(img, r, VIO2, 3, .45); vgrad(img, r, hexc('2a1850'), hexc('160f28')); rect(img, r, outline=VIO2)
    d.line([(r[0] + 1, r[1] + 1), (r[2] - 1, r[1] + 1)], fill=hexc('4c2f86'))
    sprite(img, r[0] + 5, r[1] + 3, ["....#....", "...###...", "..#####..", ".#######.", "..#####..", "...###...", "....#....", ".........", "........."], {'#': hexc('d8b8ff')})
    text(img, r[0] + 18, r[1] + 5, 'ТВОЙ РАНГ', WHITE)
    s = 'ОТКРЫТЬ >'; text(img, r[2] - 5 - text_w(s), r[1] + 5, s, hexc('d8b8ff'))
    footer(img, ['РАНГИ'], back=True)
    return img, {'Категория: Игроки': slots_in(0, 1, 2, 3), 'Категория: Донаты': slots_in(3, 1, 5, 3),
                 'Категория: Персонал': slots_in(6, 1, 8, 3), 'Твой ранг': slots_in(1, 4, 7, 4), 'Назад (закрыть)': [45], 'Закрыть': [53]}

if __name__ == '__main__':
    import os
    from PIL import ImageFont
    out = '/home/claude/zx_report/roles'; os.makedirs(out + '/native', exist_ok=True)
    F = '/usr/share/fonts/opentype/inter/Inter-%s.otf'
    def font(sz, w='SemiBold'): return ImageFont.truetype(F % w, sz)
    items = [('hub', '/rank — хаб', build_hub), ('default', 'PLAYER (default)', build_default),
             ('youtube', 'YOUTUBE', build_youtube), ('gl_admin', 'GL.ADMIN', build_gl_admin)]
    tiles = []
    for key, title, fn in items:
        g, zones = fn(); g.save(f'{out}/native/{key}_176x222.png')
        S = 3; big = g.resize((W * S, H * S), Image.NEAREST)
        ImageDraw.Draw(big).text((8 * S, 128 * S - 3), 'Inventory', font=font(7 * S - 4, 'Regular'), fill=(64, 64, 64, 255))
        tiles.append((title, big, zones))
    tw, th = tiles[0][1].width, tiles[0][1].height
    ov = Image.new('RGBA', (2 * tw + 3 * 40 + 2 * 330, 2 * (th + 50) + 140), (16, 13, 24, 255)); dd = ImageDraw.Draw(ov)
    dd.text((40, 30), 'ZENTROX — хаб /rank и меню групп: PLAYER, YOUTUBE, GL.ADMIN', font=font(38, 'Bold'), fill=(244, 239, 255))
    dd.text((40, 82), 'Макеты 1:1 (×3) · дизайн-система v4 B+ · оригинальные плашки из ресурспака · права не выдумывались', font=font(20, 'Medium'), fill=(170, 160, 200))
    for i, (title, big, zones) in enumerate(tiles):
        col, row = i % 2, i // 2
        x = 40 + col * (tw + 330 + 40); y = 140 + row * (th + 50)
        dd.text((x, y), title, font=font(24, 'Bold'), fill=(220, 210, 245)); ov.alpha_composite(big, (x, y + 36))
        ly = y + 46
        for z, ss in zones.items():
            rows = {}
            for q in ss: rows.setdefault(q // 9, []).append(q)
            rng = ', '.join(f'{r[0]}–{r[-1]}' if len(r) > 1 else str(r[0]) for r in rows.values())
            dd.text((x + tw + 20, ly), z, font=font(16, 'SemiBold'), fill=(225, 218, 245))
            dd.text((x + tw + 20, ly + 20), 'слоты ' + rng, font=font(14, 'Regular'), fill=(150, 140, 180)); ly += 48
    ov.save(f'{out}/ZENTROX_HUB_PLAYER_YOUTUBE_GLADMIN.png')
    print('ok')
