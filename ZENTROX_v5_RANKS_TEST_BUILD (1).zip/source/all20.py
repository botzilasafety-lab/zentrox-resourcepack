"""ZENTROX — все 20 меню групп LuckPerms (макеты), иерархия от 21.11 (YOUTUBE = 65)."""
import math, random
from PIL import Image, ImageDraw
from pix import *
import ranks, roles
from ranks import BG, PANEL, PANEL2, LINE, LINE2, VIOD, VIO, VIO2, WHITE, DIM, DIM2, mix, badge, glow, ic, vgrad, bevel, rect
T = ranks.T

# ---------------- иерархия (подтверждена владельцем 21.11) ----------------
WEIGHT = {'gl_admin': 100, 'st_admin': 99, 'admin': 98, 'ml_admin': 97, 'gl_moder': 96, 'st_moder': 95, 'moder': 94, 'ml_moder': 93,
          'st_helper': 92, 'helper': 91, 'builder': 70, 'youtube': 65, 'zenith': 60, 'nexus': 50, 'phantom': 40, 'inferno': 30,
          'astra': 20, 'blaze': 10, 'tester': 0, 'default': 0}
CATEGORY = {**{g: 'staff' for g in ['gl_admin', 'st_admin', 'admin', 'ml_admin', 'gl_moder', 'st_moder', 'moder', 'ml_moder', 'st_helper', 'helper', 'builder']},
            **{g: 'donate' for g in ['zenith', 'nexus', 'phantom', 'inferno', 'astra', 'blaze']},
            **{g: 'players' for g in ['youtube', 'tester', 'default']}}
BRANCH = {'admin': ['gl_admin', 'st_admin', 'admin', 'ml_admin'], 'moder': ['gl_moder', 'st_moder', 'moder', 'ml_moder'],
          'help': ['st_helper', 'helper', 'builder']}
def branch_of(g): return next(k for k, v in BRANCH.items() if g in v)
LABEL = {'default': 'PLAYER', 'gl_admin': 'GL.ADMIN', 'st_admin': 'ST.ADMIN', 'ml_admin': 'ML.ADMIN', 'gl_moder': 'GL.MODER', 'st_moder': 'ST.MODER',
         'ml_moder': 'ML.MODER', 'st_helper': 'ST.HELPER'}
def label(g): return LABEL.get(g, g.upper())

# ---------------- цвета из плашек + роль (по названию группы, без прав) ----------------
ranks.THEME.update({
 'st_admin':  dict(acc='fc5663', lit='ffc0c6', drk='631d32', tag='СТАРШИЙ АДМИН'),
 'admin':     dict(acc='fa6962', lit='ffc4c0', drk='5f1a29', tag='АДМИНИСТРАТОР'),
 'ml_admin':  dict(acc='fa97ca', lit='ffd6ec', drk='752955', tag='МЛАДШИЙ АДМИН'),
 'gl_moder':  dict(acc='b399fd', lit='e4dbff', drk='3c286c', tag='ГЛАВНЫЙ МОДЕР'),
 'st_moder':  dict(acc='75a7ff', lit='cfe0ff', drk='24417e', tag='СТАРШИЙ МОДЕР'),
 'moder':     dict(acc='66d6ea', lit='c8f4fb', drk='1c6875', tag='МОДЕРАТОР'),
 'ml_moder':  dict(acc='a5bfff', lit='dde7ff', drk='34467e', tag='МЛАДШИЙ МОДЕР'),
 'st_helper': dict(acc='6be8c8', lit='c9fbee', drk='1c725f', tag='СТАРШИЙ ХЕЛПЕР'),
 'helper':    dict(acc='80efc7', lit='d0ffef', drk='1d6050', tag='ХЕЛПЕР'),
 'builder':   dict(acc='f8c46e', lit='ffe7bf', drk='70522a', tag='СТРОИТЕЛЬ'),
 'tester':    dict(acc='b4ef79', lit='e2ffc8', drk='4b7227', tag='ТЕСТИРОВЩИК'),
})

# ---------------- рамки по веткам (одна система, разные «характеры») ----------------
STYLE = {**{g: 'rivet' for g in BRANCH['admin']}, **{g: 'chamfer' for g in BRANCH['moder']},
         'st_helper': 'soft', 'helper': 'soft', 'builder': 'brick', 'tester': 'dash'}
def frame(img, r, g):
    if g in ('default', 'youtube', 'gl_admin'): return roles.rframe(img, r, g)
    if g in ranks.DATA: return ranks.frame(img, r, g)
    acc, lit, drk = T(g); x0, y0, x1, y1 = r; d = ImageDraw.Draw(img); px = img.load(); st = STYLE[g]
    if st == 'rivet':
        rect(img, r, outline=drk); rect(img, (x0 + 1, y0 + 1, x1 - 1, y1 - 1), outline=acc)
        for (x, y) in ((x0 + 1, y0 + 1), (x1 - 1, y0 + 1), (x0 + 1, y1 - 1), (x1 - 1, y1 - 1)):
            rect(img, (x - 1, y - 1, x + 1, y + 1), fill=lit); px[x, y] = drk
    elif st == 'chamfer':
        c = 3
        d.line([(x0 + c, y0), (x1 - c, y0)], fill=acc); d.line([(x0 + c, y1), (x1 - c, y1)], fill=drk)
        d.line([(x0, y0 + c), (x0, y1 - c)], fill=acc); d.line([(x1, y0 + c), (x1, y1 - c)], fill=drk)
        for a, b in (((x0, y0 + c), (x0 + c, y0)), ((x1 - c, y0), (x1, y0 + c)), ((x0, y1 - c), (x0 + c, y1)), ((x1 - c, y1), (x1, y1 - c))):
            d.line([a, b], fill=lit)
    elif st == 'soft':
        rect(img, r, outline=mix(acc, BG, .25)); d.line([(x0 + 2, y0), (x1 - 2, y0)], fill=lit)
        for (x, y) in ((x0, y0), (x1, y0), (x0, y1), (x1, y1)): px[x, y] = BG
        for (x, y) in ((x0 + 1, y0 + 1), (x1 - 1, y0 + 1), (x0 + 1, y1 - 1), (x1 - 1, y1 - 1)): px[x, y] = acc
    elif st == 'brick':
        bevel(img, r, acc, drk)
        for x in range(x0 + 4, x1 - 2, 8): px[x, y0] = drk; px[x + 4, y1] = mix(acc, BG, .3)
    elif st == 'dash':
        for x in range(x0, x1 + 1):
            if x % 4 < 3: px[x, y0] = acc; px[x, y1] = drk
        for y in range(y0, y1 + 1):
            if y % 4 < 3: px[x0, y] = acc; px[x1, y] = drk
roles.rframe_orig = roles.rframe
def _rframe(img, r, g):
    if g in ('default', 'youtube', 'gl_admin', 'hub'): return roles.rframe_orig(img, r, g)
    return frame(img, r, g)
roles.rframe = _rframe

# ---------------- эмблемы-спрайты 2× (K=тёмный контур, D/A/L по цвету плашки) ----------------
SPR = {
 'st_admin': ["W..................W", "LW................WL", ".LW..............WL.", "..LW............WL..", "...LW..........WL...", "....LW........WL....",
              ".....LW......WL.....", "......LW....WL......", ".......LW..WL.......", "........LWWL........", "........LWWL........", ".......AL..LA.......",
              "...A..AL....LA..A...", "....AAA......AAA....", "....DAA......AAD....", "...D..D......D..D...", "..D..............D..", ".Y................Y."],
 'admin': [".....A.............", ".....AAA...........", ".....AAAAA.........", ".....A.............", "..L.L.L.L.L.L.L....", "..AAAAAAAAAAAAA....",
           "..AAAAAAAAAAAAA....", "...ADDDDDDDDDA.....", "...ADKDDDDDKDA.....", "...ADKDDDDDKDA.....", "...ADDDDDDDDDA.....", "...ADDDDWDDDDA.....",
           "...ADDDWWWDDDA.....", "...ADDKKKKKDDA.....", "...ADDKKKKKDDA.....", "...ADDKKKKKDDA.....", "..AAAAAAAAAAAAA....", ".AAAAAAAAAAAAAAA..."],
 'ml_admin': ["...LLLL....", "..LAAAAL...", ".LA....AL..", ".A..KK..A..", ".A..KK..A..", ".LA....AL..", "..AAAAAA...", "....AA.....", "....AA.....",
              "....AAAA...", "....AA.....", "....AAA....", "....AA.....", "....AAAA...", "....AA.....", ".....D....."],
 'gl_moder': [".........A..........", "........AAA.........", ".......AA.AA........", "......AA...AA.......", ".....AA.....AA......", "....AA..LLL..AA.....",
              "...AA.LLWWWLL.AA....", "..AA.LWWKKKWWL.AA...", ".AA..LWKKAKKWL..AA..", "AA...LWWKKKWWL...AA.", "A.....LLWWWLL.....A.", "AAAAAAAALLLAAAAAAAAA",
              "....................", "..D...D....D...D....", ".D...D......D...D...", "D...D........D...D.."],
 'st_moder': ["AAAAAAAAAAAAAAAA", "ALLLLLLLLLLLLLLA", "ALDDDDDDDDDDDDLA", "ALDDDDDDDDDDWDLA", "ALDDDDDDDDDWWDLA", "ALDDDDDDDDWWDDLA",
              "ALDDWDDDDWWDDDLA", "ALDDWWDDWWDDDDLA", "ALDDDWWWWDDDDDLA", "ALDDDDWWDDDDDDLA", ".ALDDDDDDDDDDLA.", ".ALDDDDDDDDDDLA.",
              "..ALDDDDDDDDLA..", "...ALDDDDDDLA...", "....ALDDDDLA....", ".....ALDDLA.....", "......ALLA......", ".......AA......."],
 'moder': ["....AAAAA.......", "..AALLLLLAA.....", ".AL.......LA....", ".AL..W....LA....", "AL..W......LA...", "AL..........A...", "AL..........A...",
           "AL..........A...", ".AL........LA...", ".AL.......LA....", "..AALLLLLAAD....", "....AAAAA.DDD...", "..........DDDD..", "...........DDDD.",
           "............DDDD", ".............DD."],
 'ml_moder': [".......A.......", "......AAA......", "......ALA......", "A....ALLLA....A", ".AAAAALWLAAAAA.", "..ALLLLWLLLLA..", "...ALLWWWLLA...",
              "....ALLWLLA....", "...ALLLLLLLA...", "...ALLAAALLA...", "..ALLA...ALLA..", "..ALA.....ALA..", ".AAA.......AAA.", ".A...........A."],
 'st_helper': ["..AAA....AAA..", ".ALLLA..ALLLA.", "ALLLLLAALLLLLA", "ALLLLLWWLLLLLA", "ALLLLLWWLLLLLA", "ALLLWWWWWWLLLA", ".ALLWWWWWWLLA.",
               "..ALLLWWLLLA..", "...ALLWWLLA...", "....ALLLLA....", ".....ALLA.....", "......AA......"],
 'helper': [".AAAAAAAAAAAAA.", "ALLLLLLLLLLLLLA", "ALLLLLKKKLLLLLA", "ALLLLKLLLKLLLLA", "ALLLLLLLLKLLLLA", "ALLLLLLLKLLLLLA", "ALLLLLLKLLLLLLA",
            "ALLLLLLKLLLLLLA", "ALLLLLLLLLLLLLA", "ALLLLLLKLLLLLLA", ".AAAALAAAAAAAA.", "....AA.........", "...A..........."],
 'builder': ["........GGGG....", ".......GWWWGG...", "......GWWWWGGG..", ".......GWWGGG...", "......B.GGG.....", ".....B..........", "....B...........",
             "...B............", "..B.............", "................", "AAADAAADAAADAAAD", "DDDDDDDDDDDDDDDD", "ADAAADAAADAAADAA", "DDDDDDDDDDDDDDDD",
             "AAADAAADAAADAAAD"],
 'tester': [".....DDDD.....", ".....KLLK.....", "......LL......", "......LL......", ".....KLLK.....", "....KL..LK....", "...KL....LK...",
            "..KL..W...LK..", "..KAAAAAAAAK..", ".KAAWAAAAAAAK.", ".KAAAAAWAAAAK.", ".KAAAAAAAAAAK.", "..KKKKKKKKKK.."],
}
MOTIF = {'st_admin': 'embers', 'admin': 'embers', 'ml_admin': 'sparkle', 'gl_moder': 'rays', 'st_moder': 'grid', 'moder': 'grid',
         'ml_moder': 'sparkle', 'st_helper': 'bubbles', 'helper': 'bubbles', 'builder': 'dust', 'tester': 'bubbles'}

def art_sprite(img, r, g):
    acc, lit, drk = T(g); x0, y0, x1, y1 = r; px = img.load(); rnd = random.Random(sum(map(ord, g)))
    vgrad(img, r, mix(BG, drk, .35), mix(BG, drk, .85))
    m = MOTIF[g]
    if m == 'embers':
        for _ in range(26): px[rnd.randint(x0, x1), rnd.randint(y0, y1 - 8)] = mix(BG, acc, rnd.choice([.4, .7, 1]))
    elif m == 'sparkle':
        for _ in range(10):
            x, y = rnd.randint(x0 + 2, x1 - 2), rnd.randint(y0 + 2, y1 - 10)
            for dx, dy in ((0, 0), (1, 0), (-1, 0), (0, 1), (0, -1)): px[x + dx, y + dy] = lit if (dx, dy) == (0, 0) else mix(BG, acc, .6)
    elif m == 'rays':
        cx, cy = (x0 + x1) // 2, y0 + 30
        for k in range(0, 360, 20):
            a = math.radians(k)
            for t in range(14, 40, 2):
                x, y = int(cx + t * math.cos(a)), int(cy + t * math.sin(a))
                if x0 <= x <= x1 and y0 <= y <= y1: px[x, y] = mix(px[x, y], acc, .25)
    elif m == 'grid':
        for y in range(y0 + 2, y1, 6):
            for x in range(x0 + 2, x1, 6): px[x, y] = mix(px[x, y], acc, .35)
    elif m == 'bubbles':
        for _ in range(9):
            x, y = rnd.randint(x0 + 3, x1 - 3), rnd.randint(y0 + 3, y1 - 12)
            for dx, dy in ((0, -1), (1, 0), (0, 1), (-1, 0)): px[x + dx, y + dy] = mix(BG, lit, .55)
    elif m == 'dust':
        for _ in range(30): px[rnd.randint(x0, x1), rnd.randint(y0 + 30, y1 - 6)] = mix(BG, acc, .4)
    rows = SPR[g]; w = max(len(s) for s in rows); h = len(rows); S = 2
    ox = (x0 + x1 + 1) // 2 - w * S // 2; oy = y0 + 8 + max(0, (40 - h * S) // 2)
    pal = {'A': acc, 'L': lit, 'D': drk, 'W': WHITE, 'K': mix(drk, BG, .5), 'Y': hexc('ffcf4a'), 'G': hexc('9aa0ad'), 'B': hexc('8a5a32')}
    glow(img, (ox, oy, ox + w * S - 1, oy + h * S - 1), acc, 4, .25)
    sprite(img, ox, oy, rows, pal, S)
    for y in range(y1 - 6, y1 + 1):
        for x in range(x0, x1 + 1): px[x, y] = mix(BG, drk, .6) if (x + y) % 6 else mix(BG, drk, .9)

for g in SPR: roles.ART[g] = (lambda gg: (lambda img, r: art_sprite(img, r, gg)))(g)

def name_tag(img, g):
    t = ranks.THEME[g]['tag']; acc = T(g)[0]
    text(img, 9, 24, t, mix(acc, WHITE, .35))

# ---------------- шаблон «персонал» ----------------
def build_staff(g):
    img = roles.base(g); roles.header(img, g); roles.info_plate(img, g, 'ВЕС', str(WEIGHT[g])); roles.emblem(img, g)
    br = BRANCH[branch_of(g)]
    zones = {'Вес (инфо)': [6, 7, 8], 'Эмблема: роль и место в иерархии': slots_in(0, 1, 2, 4)}
    for i, b in enumerate(br):
        acc, lit, drk = T(b); cur = b == g
        x0, y0, x1, y1 = area(3, 1 + i, 8, 1 + i); r = (x0 + 2, y0 + 1, x1 - 1, y1 - 1)
        if cur: glow(img, r, T(g)[0], 3, .45)
        vgrad(img, r, mix(PANEL2, drk, .55 if cur else .2), PANEL)
        if cur: frame(img, r, g)
        else: rect(img, r, outline=mix(acc, BG, .6))
        bd = badge(b)
        if not cur:
            bd = bd.copy(); p = bd.load()
            for yy in range(bd.height):
                for xx in range(bd.width):
                    q = p[xx, yy]
                    if q[3]: p[xx, yy] = tuple(int(c * .6 + 20) for c in q[:3]) + (q[3],)
        bx = r[0] + 2; img.alpha_composite(bd, (bx, r[1] + 1))
        ws = str(WEIGHT[b]); wx = max(bx + bd.width + 3, r[2] - 4 - text_w(ws))
        if wx + text_w(ws) <= r[2] - 1: text(img, wx, r[1] + 5, ws, lit if cur else DIM2)
        zones[f'{label(b)}' + (' (текущий)' if cur else ' → меню')] = slots_in(3, 1 + i, 8, 1 + i)
    if len(br) == 3:  # ветка помощников: 4-я строка — роль (текст от владельца)
        roles.bar(img, 4, g, 'info', 'ОПИСАНИЕ РОЛИ', '?')
        zones['Описание роли (текст от владельца)'] = slots_in(3, 4, 8, 4)
    roles.footer(img, ['РАНГИ', 'ПЕРСОНАЛ', label(g)])
    zones['Назад → Персонал'] = [45]; zones['Закрыть'] = [53]
    return img, zones

# ---------------- шаблон «спец-группа» (YOUTUBE, TESTER) ----------------
def build_special(g, role1, role2):
    img = roles.base(g); roles.header(img, g); roles.info_plate(img, g, 'ВЕС', str(WEIGHT[g])); roles.emblem(img, g)
    acc, lit, drk = T(g)
    x0, y0, _, _ = area(3, 1, 8, 1); _, _, x1, y1 = area(3, 2, 8, 2); r = (x0 + 2, y0 + 1, x1 - 1, y1 - 1)
    vgrad(img, r, mix(PANEL2, drk, .4), PANEL); frame(img, r, g)
    text(img, r[0] + 6, r[1] + 5, 'РОЛЬ', DIM)
    text(img, r[0] + 6, r[1] + 15, role1, lit, scale=2, shadow=drk)
    if role2: text(img, r[0] + 6 + text_w(role1, 2) + 6, r[1] + 22, role2, lit, shadow=drk)
    roles.bar(img, 3, g, 'info', 'УСЛОВИЯ ПОЛУЧЕНИЯ', '?')
    roles.bar(img, 4, g, 'send', 'СВЯЗЬ', '?')
    roles.footer(img, ['РАНГИ', 'ИГРОКИ', label(g)])
    return img, {'Вес (инфо)': [6, 7, 8], 'Эмблема: роль': slots_in(0, 1, 2, 4), 'Роль': slots_in(3, 1, 8, 2),
                 'Условия — не заполнено': slots_in(3, 3, 8, 3), 'Связь — не заполнено': slots_in(3, 4, 8, 4),
                 'Назад → Игроки': [45], 'Закрыть': [53]}

def build_donate(g):
    img = ranks.build(g)
    return img, {'Цена (покупки отключены)': [6, 7, 8], 'Эмблема': slots_in(0, 1, 2, 4), 'Аукцион': slots_in(3, 1, 8, 1), 'Приваты': slots_in(3, 2, 8, 2),
                 'Дома': slots_in(3, 3, 8, 3), 'Команда': slots_in(3, 4, 8, 4), 'Назад → Донаты': [45], 'Лестница PLAYER…ZENITH': list(range(46, 53)), 'Закрыть': [53]}

def build(g):
    if g == 'default': return roles.build_default()
    if g == 'youtube': return build_special('youtube', 'АВТОР', 'КОНТЕНТА')
    if g == 'tester': return build_special('tester', 'ТЕСТЕР', '')
    if CATEGORY[g] == 'donate': return build_donate(g)
    return build_staff(g)

ORDER = sorted(WEIGHT, key=lambda g: (-WEIGHT[g], ['tester', 'default'].index(g) if g in ('tester', 'default') else 0))

if __name__ == '__main__':
    import os
    from PIL import ImageFont
    out = '/home/claude/zx_report/all20'; os.makedirs(out + '/native', exist_ok=True); os.makedirs(out + '/single', exist_ok=True)
    F = '/usr/share/fonts/opentype/inter/Inter-%s.otf'
    def font(sz, w='SemiBold'): return ImageFont.truetype(F % w, sz)
    S = 2; built = {}
    for g in ORDER:
        im, zones = build(g); im.save(f'{out}/native/{g}_176x222.png'); built[g] = (im, zones)
        big = im.resize((W * 3, H * 3), Image.NEAREST); big.save(f'{out}/single/{g}.png')
    # overview: three category blocks
    cats = [('ПЕРСОНАЛ · 11 групп · вес 70–100', [g for g in ORDER if CATEGORY[g] == 'staff']),
            ('ИГРОКИ И СПЕЦ-ГРУППЫ · YOUTUBE 65 · TESTER 0 · PLAYER 0', [g for g in ORDER if CATEGORY[g] == 'players']),
            ('ДОНАТЫ · вес 10–60', [g for g in ORDER if CATEGORY[g] == 'donate'])]
    tw, th = W * S, H * S; cols = 6; gap = 26
    rows_total = sum((len(gs) + cols - 1) // cols for _, gs in cats)
    ov = Image.new('RGBA', (cols * (tw + gap) + 60, 160 + rows_total * (th + 64) + len(cats) * 60), (16, 13, 24, 255)); dd = ImageDraw.Draw(ov)
    dd.text((40, 30), 'ZENTROX — 20 меню групп LuckPerms (макеты 1:1, ×2)', font=font(40, 'Bold'), fill=(244, 239, 255))
    dd.text((40, 86), 'Отсортировано по весу. Плашки — оригинальные из ресурспака. Права не показываются; у персонала — вес и место в ветке.', font=font(20, 'Medium'), fill=(170, 160, 200))
    y = 150
    for title, gs in cats:
        dd.text((40, y), title, font=font(26, 'Bold'), fill=(200, 185, 245)); y += 50
        for i, g in enumerate(gs):
            x = 40 + (i % cols) * (tw + gap); yy = y + (i // cols) * (th + 64)
            dd.text((x, yy), f'{label(g)} · {WEIGHT[g]}', font=font(20, 'SemiBold'), fill=(225, 218, 245))
            ov.alpha_composite(built[g][0].resize((tw, th), Image.NEAREST), (x, yy + 32))
        y += ((len(gs) + cols - 1) // cols) * (th + 64) + 10
    ov.save(f'{out}/ZENTROX_ALL20_OVERVIEW.png')
    print('ok', ORDER)
