import json, re, zipfile, io, yaml, glob, os, sys
from PIL import Image
sys.path.insert(0,'/home/claude/concepts')
import all20
OUT='/home/claude/zx_v5'; Z=zipfile.ZipFile(f'{OUT}/ZENTROX_RESOURCEPACK_v5_RANKS_1.21.11.zip'); N=set(Z.namelist())
V4=zipfile.ZipFile('/home/claude/zx_out/ZENTROX_RESOURCEPACK_v4_GUI_B_1.21.11.zip')
O=zipfile.ZipFile('/home/claude/zx_in/ORIGINAL_20_RANKS/ZENTROX_GUI_AND_20_RANKS_FIXED_1.21.11.zip')
man=json.load(open(f'{OUT}/build_manifest.json',encoding='utf-8'))
R=[]
def r(c,m): R.append(('OK  ' if c else 'FAIL')+' '+m)
# ---- pack ----
r('pack.mcmeta' in N and Z.read('pack.mcmeta')==V4.read('pack.mcmeta'),'pack.mcmeta в корне, идентичен v4 (format 75)')
v4diff=[n for n in V4.namelist() if not n.endswith('/') and (n not in N or Z.read(n)!=V4.read(n))]
r(v4diff==['assets/minecraft/font/default.json'],f'все {len(V4.namelist())} файлов v4 (выбор режима, gui_v2, плашки) сохранены байт-в-байт, кроме default.json')
rk=[n for n in O.namelist() if 'rank' in n and not n.endswith('/')]
r(all(Z.read(n)==O.read(n) for n in rk),f'плашки рангов: {len(rk)} файлов идентичны оригиналу')
old=json.loads(V4.read('assets/minecraft/font/default.json'))['providers']; new=json.loads(Z.read('assets/minecraft/font/default.json'))['providers']
r([p for p in new if p in old]==old,'default.json: все провайдеры v4 на месте и в прежнем порядке (U+E110, E111, E112, плашки E220–E233)')
added=[p for p in new if p not in old]
codes=[p['chars'][0] for p in added]
r(len(added)==24 and len(set(codes))==24 and all(0xE113<=ord(c)<=0xE12A for c in codes),'добавлено ровно 24 символа фона U+E113…U+E12A, без дублей')
allc=[c for p in new for c in ''.join(p.get('chars',[]))]+[c for p in new for c in p.get('advances',{})]
r(len(allc)==len(set(allc)),f'во всём default.json {len(allc)} символов — ни одного конфликта кодов')
iref=min(i for i,p in enumerate(new) if p['type']=='reference')
r(all(new.index(p)<iref for p in added),'новые глифы стоят до include/* (приоритет)')
bad=[n for n in N if n.startswith('assets/') and not re.fullmatch(r'assets/[a-z0-9_.-]+/[a-z0-9_./-]+',n)]
r(not bad,f'{len(N)} путей — допустимые resource location')
for p in added:
    ns,f=p['file'].split(':'); im=Image.open(io.BytesIO(Z.read(f'assets/{ns}/textures/{f}')))
    assert im.size==(176,222) and p['ascent']==13 and p['height']==222
r(True,'24 фона 176×222, ascent 13 / height 222 — как у работающего v4')
r(not any(n.startswith(('assets/minecraft/items/','assets/minecraft/models/','assets/minecraft/textures/')) for n in N),'ванильные предметы/текстуры не переопределяются')
# ---- YAML ----
gm=yaml.safe_load('gui_menus:\n'+'\n'.join(l for l in open(f'{OUT}/GUI_MENUS_ADD.yml',encoding='utf-8') if not l.startswith('#')))['gui_menus']
r(len(gm)==24 and not ({'zentrox_ranks','servers'}&set(gm)),'GUI_MENUS_ADD: 24 новых записи zxr_*, нет конфликтов с zentrox_ranks и servers')
files=sorted(glob.glob(f'{OUT}/gui_menus/*.yml'))
r(sorted(os.path.basename(f) for f in files)==sorted(v['file'] for v in gm.values()),'каждой записи gui_menus соответствует файл, лишних файлов нет')
code_of={k:v for k,v in man['codes'].items()}
problems=[]; opens=0
for f in files:
    name=os.path.basename(f)[:-4]; y=yaml.safe_load(open(f,encoding='utf-8')); it=y['items']
    if y['menu_title']!='&f'+chr(int(code_of[name][2:],16)): problems.append(f'{name}: title')
    if y['size']!=54: problems.append(f'{name}: size')
    if ('open_command' in y)!=(name=='zxr_hub'): problems.append(f'{name}: open_command')
    if name=='zxr_hub' and (y['open_command']!='zentroxranks' or y['register_command'] is not True): problems.append('hub cmd')
    slotmap={}
    for k,v in it.items():
        assert v['material']=='PAPER' and v['item_model']=='zentrox:gui_b/blank'
        for s in v['slots']: slotmap.setdefault(s,[]).append(k)
        for c in v.get('click_commands',[]):
            low=c.lower()
            if any(x in low for x in ['[console]','[player]','lp ','luckperms','op ','give','permission','[commandevent]']): problems.append(f'{name}/{k}: команда {c}')
            m=re.match(r'\[openguimenu\] (\S+)$',c)
            if m:
                opens+=1
                if m.group(1) not in gm: problems.append(f'{name}/{k}: нет меню {m.group(1)}')
    for s,ks in slotmap.items():
        if len(ks)>1 and not all('priority' in it[k] for k in ks): problems.append(f'{name}: слот {s} занят {ks}')
        if not 0<=s<=53: problems.append(f'{name}: слот {s}')
    # 45 / 53
    b=[k for k in it if 45 in it[k]['slots']]; c=[k for k in it if 53 in it[k]['slots']]
    if len(b)!=1 or len(c)!=1: problems.append(f'{name}: 45/53 {b} {c}')
    else:
        if it[c[0]]['click_commands']!=['[close]']: problems.append(f'{name}: 53 не закрывает')
        exp=['[close]'] if name=='zxr_hub' else ['[openguimenu] '+man['parent'][name]]
        if it[b[0]]['click_commands']!=exp: problems.append(f'{name}: 45 → {it[b[0]]["click_commands"]}, ждали {exp}')
    # slots vs designed zones
    key=name[4:]; zones=man['zones'][key]; zslots=set(s for v in zones.values() for s in v)
    if set(slotmap)!=zslots: problems.append(f'{name}: слоты {sorted(set(slotmap)^zslots)} не совпадают с графикой')
r(not problems,f'24 меню: заголовки, размер 54, 45/53, переходы, слоты = графика, нет команд выдачи прав'+('' if not problems else ' :: '+'; '.join(problems[:12])))
r(opens>0,f'проверено переходов [openguimenu]: {opens}, все ведут на существующие zxr_* меню')
# your rank
hub=yaml.safe_load(open(f'{OUT}/gui_menus/zxr_hub.yml',encoding='utf-8'))['items']
yr=sorted([(v['priority'],k[10:],v) for k,v in hub.items() if k.startswith('your_rank_')])
order=[g for _,g,_ in yr]
r(order==all20.ORDER,'«Твой ранг»: priority 1…20 = '+' > '.join(order))
r(all(v['view_requirement']['requirements'][f'in_{g}']['input']==f'%luckperms_inherits_group_{g}%' for _,g,v in yr if g!='default') and 'view_requirement' not in hub['your_rank_default'],
  '«Твой ранг»: условие inherits_group (наследование + несколько групп), PLAYER — запасной вариант без условия')
r(order.index('builder')<order.index('youtube')<order.index('zenith'),'YOUTUBE ниже BUILDER и выше ZENITH')
r(all(v['click_commands']==[f'[openguimenu] zxr_{g}'] for _,g,v in yr),'каждый вариант «Твой ранг» открывает меню своей группы')
txt=open(f'{OUT}/validation_report.txt','w',encoding='utf-8'); txt.write('\n'.join(R)+'\n'); print('\n'.join(R)); print('FAILS',sum(x.startswith('FAIL') for x in R))
