"""ZENTROX — 3 меню категорий + обзор системы из 24 меню."""
import math
from PIL import Image, ImageDraw
from pix import *
import ranks, roles, all20
from ranks import BG, PANEL, PANEL2, LINE, LINE2, VIOD, VIO, VIO2, WHITE, DIM, DIM2, mix, glow, vgrad, bevel, rect
T = ranks.T; WEIGHT = all20.WEIGHT; label = all20.label

def head(img, title, right):
    d = ImageDraw.Draw(img)
    hp = (6, 3, W - 7, 23); vgrad(img, hp, hexc('1c1433'), hexc('100b1d')); rect(img, hp, outline=LINE2)
    text(img, 12, 6, 'ZENTROX', WHITE, scale=2, sp=1, shadow=VIO)
    tw = text_w(title); text(img, W - 12 - tw, 6, title, WHITE)
    text(img, W - 12 - text_w(right), 14, right, DIM)
    d.line([(12, 21), (80, 21)], fill=VIO2)

def emblem_into(g, w, h):
    """рисует эмблему группы в отдельный холст w×h (тот же код, что в меню группы)"""
    tmp = Image.new('RGBA', (W, H), BG)
    r = (2, 2, 2 + w - 1, 2 + h - 1)
    if g in ranks.ART: ranks.ART[g](tmp, r)
    else: roles.ART[g](tmp, r)
    return tmp.crop((2, 2, 2 + w, 2 + h))

# ---------------- Игроки и спец-группы ----------------
def build_players():
    img = roles.base('hub'); head(img, 'ИГРОКИ', '3 ГРУППЫ')
    zones = {}
    for i, g in enumerate(['youtube', 'tester', 'default']):
        acc, lit, drk = T(g)
        x0, y0, x1, y1 = area(3 * i, 1, 3 * i + 2, 4); r = (x0 + 2, y0 + 1, x1 - 2, y1 - 1)
        glow(img, r, acc, 4 if g == 'youtube' else 3, .45 if g == 'youtube' else .3)
        art = emblem_into(g, r[2] - r[0] - 3, 66).crop((0, 8, r[2] - r[0] - 3, 56)); img.alpha_composite(art, (r[0] + 2, r[1] + 2))
        vgrad(img, (r[0] + 1, r[1] + 51, r[2] - 1, r[3] - 1), mix(PANEL2, drk, .45), PANEL)
        all20.frame(img, r, g)
        cx = (r[0] + r[2]) // 2
        text_c(img, cx, r[1] + 54, label(g), WHITE, shadow=BG)
        text_c(img, cx, r[1] + 63, f'ВЕС {WEIGHT[g]}', mix(acc, WHITE, .3))
        zones[label(g) + ' → меню группы'] = slots_in(3 * i, 1, 3 * i + 2, 4)
    roles.footer(img, ['РАНГИ', 'ИГРОКИ'])
    zones['Назад → хаб'] = [45]; zones['Закрыть'] = [53]
    return img, zones

# ---------------- Донатные привилегии ----------------
def build_donates():
    img = roles.base('hub'); head(img, 'ДОНАТЫ', '6 ПРИВИЛЕГИЙ')
    zones = {}
    order = ['blaze', 'astra', 'inferno', 'phantom', 'nexus', 'zenith']
    for i, g in enumerate(order):
        acc, lit, drk = T(g); c0 = 3 * (i % 3); r0 = 1 + 2 * (i // 3)
        x0, y0, x1, y1 = area(c0, r0, c0 + 2, r0 + 1); r = (x0 + 2, y0 + 1, x1 - 2, y1 - 1)
        glow(img, r, acc, 4 if g == 'zenith' else 3, .5 if g == 'zenith' else .3)
        full = emblem_into(g, r[2] - r[0] - 1, 66)
        oy = {'blaze': 30, 'astra': 28, 'inferno': 30, 'phantom': 8, 'nexus': 20, 'zenith': 14}[g]
        art = full.crop((0, oy, full.width, oy + 22)); img.alpha_composite(art, (r[0] + 1, r[1] + 1))
        vgrad(img, (r[0] + 1, r[1] + 23, r[2] - 1, r[3] - 1), mix(PANEL2, drk, .5), PANEL)
        ranks.frame(img, r, g)
        text(img, r[0] + 4, r[1] + 25, label(g), WHITE, shadow=BG)
        ps = f'{ranks.DATA[g]["price"]}₽'; pw = text_w(ps)
        rect(img, (r[2] - pw - 7, r[1] + 2, r[2] - 2, r[1] + 11), fill=hexc('0b0812'), outline=acc)
        text(img, r[2] - pw - 4, r[1] + 3, ps, lit)
        zones[label(g) + ' → меню'] = slots_in(c0, r0, c0 + 2, r0 + 1)
    roles.footer(img, ['РАНГИ', 'ДОНАТЫ'])
    zones['Назад → хаб'] = [45]; zones['Закрыть'] = [53]
    return img, zones

# ---------------- Команда ZENTROX ----------------
def build_staff():
    img = roles.base('hub'); head(img, 'КОМАНДА', '11 ГРУПП')
    zones = {}
    cols = [('АДМИНЫ', all20.BRANCH['admin'], 'gl_admin'), ('МОДЕРАЦИЯ', all20.BRANCH['moder'], 'gl_moder'), ('ПОМОЩНИКИ', all20.BRANCH['help'], 'st_helper')]
    for ci, (title, groups, lead) in enumerate(cols):
        acc = T(lead)[0]; c0 = 3 * ci
        x0, _, x1, _ = area(c0, 1, c0 + 2, 1); _, _, _, y1 = area(c0, 4, c0 + 2, 4)
        col = (x0 + 1, 25, x1 - 1, y1 - 1)
        vgrad(img, col, mix(PANEL, T(lead)[2], .25), mix(BG, PANEL, .5)); all20.frame(img, col, lead)
        text_c(img, (col[0] + col[2]) // 2, 28, title, mix(acc, WHITE, .35))
        for gi, g in enumerate(groups):
            gacc, glit, gdrk = T(g)
            ex0, ey0, ex1, ey1 = area(c0, 1 + gi, c0 + 2, 1 + gi); e = (ex0 + 2, ey0 + 2, ex1 - 2, ey1 - 2)
            vgrad(img, e, mix(PANEL2, gdrk, .5), PANEL); rect(img, e, outline=mix(gacc, BG, .35))
            rect(img, (e[0] + 2, e[1] + 4, e[0] + 3, e[1] + 9), fill=gacc)
            text(img, e[0] + 6, e[1] + 4, label(g), WHITE if gi == 0 else mix(WHITE, gacc, .25))
            zones[label(g) + ' → меню'] = slots_in(c0, 1 + gi, c0 + 2, 1 + gi)
        if len(groups) == 3:  # пустая 4-я строка ветки помощников — без кнопки
            ex0, ey0, ex1, ey1 = area(c0, 4, c0 + 2, 4)
            for x in range(ex0 + 8, ex1 - 6, 4): img.load()[x, (ey0 + ey1) // 2] = LINE2
    roles.footer(img, ['РАНГИ', 'КОМАНДА'])
    zones['Назад → хаб'] = [45]; zones['Закрыть'] = [53]
    return img, zones

if __name__ == '__main__':
    import os
    from PIL import ImageFont
    out = '/home/claude/zx_report/system24'; os.makedirs(out + '/native', exist_ok=True); os.makedirs(out + '/single', exist_ok=True)
    F = '/usr/share/fonts/opentype/inter/Inter-%s.otf'
    def font(sz, w='SemiBold'): return ImageFont.truetype(F % w, sz)
    tops = [('hub', '/rank — хаб', roles.build_hub), ('cat_players', 'Игроки и спец-группы', build_players),
            ('cat_donate', 'Донатные привилегии', build_donates), ('cat_staff', 'Команда ZENTROX', build_staff)]
    built = {}
    for key, title, fn in tops:
        im, zones = fn(); im.save(f'{out}/native/{key}_176x222.png'); im.resize((W * 3, H * 3), Image.NEAREST).save(f'{out}/single/{key}.png')
        built[key] = (title, im, zones)
    groups = {}
    for g in all20.ORDER:
        im, zones = all20.build(g); im.save(f'{out}/native/{g}_176x222.png'); im.resize((W * 3, H * 3), Image.NEAREST).save(f'{out}/single/{g}.png')
        groups[g] = im
    # ---- overview: level 1-2 at x2, level 3 at x1 ----
    S2 = 2; tw, th = W * S2, H * S2; gap = 34
    top_w = 4 * tw + 3 * gap
    cw, ch = W, H; cg = 16
    cols_per = {'players': 3, 'donate': 6, 'staff': 11}
    ov = Image.new('RGBA', (top_w + 80, 3200), (16, 13, 24, 255)); dd = ImageDraw.Draw(ov)
    dd.text((40, 28), 'ZENTROX — система меню рангов: 24 меню', font=font(40, 'Bold'), fill=(244, 239, 255))
    dd.text((40, 82), 'Хаб /rank → 3 категории → 20 групп LuckPerms. «Назад» (45) — на уровень выше, «Закрыть» — 53. Покупки не подключены.', font=font(19, 'Medium'), fill=(170, 160, 200))
    y = 140
    for i, key in enumerate(['hub', 'cat_players', 'cat_donate', 'cat_staff']):
        title, im, _ = built[key]; x = 40 + i * (tw + gap)
        dd.text((x, y), ('Уровень 1 · ' if key == 'hub' else 'Уровень 2 · ') + title, font=font(20, 'SemiBold'), fill=(225, 218, 245))
        ov.alpha_composite(im.resize((tw, th), Image.NEAREST), (x, y + 32))
    y += th + 70
    dd.text((40, y), 'Уровень 3 · 20 меню групп (по весу)', font=font(24, 'Bold'), fill=(200, 185, 245)); y += 46
    rowsets = [('Персонал', [g for g in all20.ORDER if all20.CATEGORY[g] == 'staff']),
               ('Игроки и спец-группы', [g for g in all20.ORDER if all20.CATEGORY[g] == 'players']),
               ('Донаты', [g for g in all20.ORDER if all20.CATEGORY[g] == 'donate'])]
    per_row = 8; x = 40
    for name, gs in rowsets:
        dd.text((40, y), name, font=font(18, 'SemiBold'), fill=(170, 160, 200)); y += 28
        for j, g in enumerate(gs):
            xx = 40 + (j % per_row) * (cw + cg); yy = y + (j // per_row) * (ch + 34)
            dd.text((xx, yy), f'{label(g)} · {WEIGHT[g]}', font=font(14, 'SemiBold'), fill=(220, 212, 240))
            ov.alpha_composite(groups[g], (xx, yy + 20))
        y += ((len(gs) + per_row - 1) // per_row) * (ch + 34) + 12
    ov = ov.crop((0, 0, ov.width, y + 20)); ov.save(f'{out}/ZENTROX_SYSTEM_24_MENUS.png')
    # categories sheet with slot maps
    print('ok', {k: list(v[2].keys()) for k, v in built.items()})
