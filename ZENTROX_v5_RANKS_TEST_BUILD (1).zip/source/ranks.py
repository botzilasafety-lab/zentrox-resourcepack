"""ZENTROX — макеты индивидуальных меню донатных привилегий (DeluxeMenus, 54 слота).
Единая сетка (дизайн-система), разные темы. Данные — только из брифа 21.11."""
import math, random, io, zipfile
from PIL import Image, ImageDraw
from pix import *

BG = hexc('0a0810'); PANEL = hexc('120e1c'); PANEL2 = hexc('181226'); LINE = hexc('2a2338'); LINE2 = hexc('3b3350')
VIOD = hexc('3b1a6e'); VIO = hexc('7c3aed'); VIO2 = hexc('a855f7'); WHITE = hexc('f6f1ff'); DIM = hexc('9a8fb5'); DIM2 = hexc('5f5577')

def mix(p, c, a): return tuple(int(p[i] * (1 - a) + c[i] * a) for i in range(3)) + (255,)

PACK = zipfile.ZipFile('/home/claude/zx_out/ZENTROX_RESOURCEPACK_v4_GUI_B_1.21.11.zip')
def badge(name):
    return Image.open(io.BytesIO(PACK.read(f'assets/zentrox/textures/font/rank_{name}.png'))).convert('RGBA')

# --- данные строго из брифа (таблица лимитов, цены, по одной команде на ранг) ---
# значения на согласовании у владельца: в текстуру не запекаются, только в подсказку
UNRESOLVED = {('zenith', 'auc'), ('phantom', 'prv')}
TIERS = ['player', 'blaze', 'astra', 'inferno', 'phantom', 'nexus', 'zenith']
DATA = {
 'player':  dict(price=None, auc=4,   prv=1,  home=1,  cmd=None),
 'blaze':   dict(price=30,  auc=8,   prv=2,  home=2,  cmd='/hat'),
 'astra':   dict(price=60,  auc=16,  prv=4,  home=4,  cmd='/workbench'),
 'inferno': dict(price=120, auc=32,  prv=8,  home=8,  cmd='/disposal'),
 'phantom': dict(price=199, auc=64,  prv=8,  home=16, cmd='/tptoggle'),
 'nexus':   dict(price=299, auc=128, prv=16, home=32, cmd='/compass'),
 'zenith':  dict(price=699, auc=258, prv=32, home=64, cmd='/depth'),
}
THEME = {
 'player':  dict(acc='9aa0ad', lit='e2e4ea', drk='3a3d48', tag=''),
 'blaze':   dict(acc='ff9f1c', lit='ffd27a', drk='7a3300', tag='ОГНЕННЫЙ РАНГ'),
 'astra':   dict(acc='5ad7ff', lit='c9f3ff', drk='12506e', tag='КОСМИЧЕСКИЙ РАНГ'),
 'inferno': dict(acc='ff4242', lit='ffa08a', drk='650a14', tag='АДСКОЕ ПЛАМЯ'),
 'phantom': dict(acc='b48cff', lit='ece2ff', drk='45277f', tag='ПРИЗРАЧНЫЙ РАНГ'),
 'nexus':   dict(acc='2fe6c8', lit='bafff3', drk='0a5a52', tag='ЭНЕРГИЯ И ТЕХНОЛОГИИ'),
 'zenith':  dict(acc='ffcf4a', lit='fff1b8', drk='7a5600', tag='ЛЕГЕНДАРНЫЙ РАНГ'),
}
def T(rank):
    t = THEME[rank]; return hexc(t['acc']), hexc(t['lit']), hexc(t['drk'])

# ---------- slot zones (common for all six) ----------
ZONES = {
 'Цена/покупка': [6, 7, 8],
 'Эмблема': slots_in(0, 1, 2, 4),
 'Аукцион': slots_in(3, 1, 8, 1),
 'Приваты': slots_in(3, 2, 8, 2),
 'Дома': slots_in(3, 3, 8, 3),
 'Команда': slots_in(3, 4, 8, 4),
 'Назад в /rank': [45],
 'Лестница рангов': [46, 47, 48, 49, 50, 51, 52],
 'Закрыть': [53],
}

# ---------- small icons 11x11 ----------
IC = {
 'auc': ["..#####....", ".#.....#...", "#...#...#..", "#..###..#..", "#..#.#..#..", "#...#...#..", "#..#.#..#..", "#..###..#..", "#...#...#..", ".#.....#...", "..#####...."],
 'prv': ["#########..", "#.......#..", "#.#####.#..", "#.#...#.#..", "#.#...#.#..", "#.#####.#..", ".#.....#...", ".#.....#...", "..#...#....", "...#.#.....", "....#......"],
 'home': ["....#......", "...###.....", "..#####....", ".#######...", "#########..", ".#.....#...", ".#.###.#...", ".#.#.#.#...", ".#.#.#.#...", ".#.###.#...", ".#######..."],
 'cmd': ["#########..", "#.......#..", "#.#.....#..", "#..#....#..", "#...#...#..", "#..#....#..", "#.#..##.#..", "#.......#..", "#########..", "...........", "..........."],
}
def ic(img, x, y, k, col): sprite(img, x, y, IC[k], {'#': col})

# ---------- emblem art (panel inner 52x70: x8..59, y36..105) ----------
def flame(img, cx, base, h, w, cols, seed=1, lean=0.0):
    px = img.load(); rnd = random.Random(seed)
    for y in range(base, base - h, -1):
        t = (base - y) / h
        hw = w * (1 - t) ** 0.7 * (0.75 + 0.25 * math.sin(t * 9 + seed))
        off = lean * t * t * w + 1.2 * math.sin(t * 7 + seed)
        for x in range(int(cx + off - hw), int(cx + off + hw) + 1):
            d = abs(x - (cx + off)) / max(hw, .5)
            k = min(len(cols) - 1, int((d * .65 + t * .5) * len(cols)))
            if rnd.random() < .06 and t > .5: continue
            px[x, y] = cols[k]

def emblem_bg(img, r, c1, c2):
    vgrad(img, r, c1, c2)

def art_blaze(img, r):
    x0, y0, x1, y1 = r; cx = (x0 + x1) // 2; px = img.load(); rnd = random.Random(5)
    emblem_bg(img, r, hexc('140a10'), hexc('3a160c'))
    for _ in range(26):  # embers
        x, y = rnd.randint(x0 + 1, x1 - 1), rnd.randint(y0 + 1, y1 - 20); px[x, y] = rnd.choice([hexc('ffb347'), hexc('ff7a1a'), hexc('ffd27a')])
    # brazier
    rect(img, (cx - 12, y1 - 16, cx + 12, y1 - 12), fill=hexc('3a2a4a')); rect(img, (cx - 9, y1 - 12, cx + 9, y1 - 6), fill=hexc('2a1f38'))
    rect(img, (cx - 12, y1 - 16, cx + 12, y1 - 16), fill=hexc('6b5590')); rect(img, (cx - 4, y1 - 6, cx + 4, y1 - 3), fill=hexc('2a1f38'))
    cols = [hexc('fff6d6'), hexc('ffd27a'), hexc('ffa62b'), hexc('ff7a1a'), hexc('c2410c'), hexc('7a2a10')]
    flame(img, cx - 6, y1 - 17, 26, 6, cols, 3, -.4); flame(img, cx + 6, y1 - 17, 24, 6, cols, 9, .4); flame(img, cx, y1 - 17, 38, 9, cols, 2)

def art_astra(img, r):
    x0, y0, x1, y1 = r; cx = (x0 + x1) // 2; px = img.load(); rnd = random.Random(8)
    emblem_bg(img, r, hexc('06081c'), hexc('1a1446'))
    for _ in range(60):
        x, y = rnd.randint(x0, x1), rnd.randint(y0, y1); px[x, y] = rnd.choice([WHITE, hexc('c9f3ff'), hexc('7c88c9')])
    # constellation
    pts = [(x0 + 6, y0 + 8), (x0 + 16, y0 + 14), (x0 + 27, y0 + 9), (x1 - 8, y0 + 16), (x1 - 4, y0 + 6)]
    d = ImageDraw.Draw(img)
    for a, b in zip(pts, pts[1:]): d.line([a, b], fill=hexc('2f5f8a'))
    for p in pts: d.point(p, fill=WHITE); d.point((p[0] + 1, p[1]), fill=hexc('5ad7ff'))
    # planet
    pcx, pcy, R = cx, y0 + 42, 13
    for y in range(pcy - R, pcy + R + 1):
        for x in range(pcx - R, pcx + R + 1):
            dd = (x - pcx) ** 2 + (y - pcy) ** 2
            if dd <= R * R:
                lt = ((x - pcx) * -.6 + (y - pcy) * -.8) / R
                band = int((y - pcy + 20) / 4) % 2
                base = hexc('3aa0d8') if band else hexc('2b7fb8')
                px[x, y] = mix(base, hexc('c9f3ff') if lt > 0 else hexc('0a1a40'), min(.7, abs(lt) * .6))
    for t in range(0, 360, 2):  # ring
        a = math.radians(t); x = int(pcx + 22 * math.cos(a)); y = int(pcy + 6 * math.sin(a) - 2 * math.cos(a))
        if (x - pcx) ** 2 + (y - pcy) ** 2 > R * R or math.sin(a) > 0:
            if x0 <= x <= x1: px[x, y] = hexc('c9f3ff') if t % 6 else hexc('5ad7ff')
    # shooting star
    for k in range(10): px[x0 + 8 + k, y1 - 10 - k // 2] = mix(hexc('06081c'), WHITE, k / 10)

def art_inferno(img, r):
    x0, y0, x1, y1 = r; cx = (x0 + x1) // 2; px = img.load(); rnd = random.Random(4)
    emblem_bg(img, r, hexc('1a0508'), hexc('4a0a10'))
    # obsidian ground with lava cracks
    for y in range(y1 - 14, y1 + 1):
        for x in range(x0, x1 + 1): px[x, y] = hexc('15101d') if (x * 7 + y * 3) % 11 else hexc('241a30')
    for _ in range(5):
        x, y = rnd.randint(x0 + 2, x1 - 2), y1 - 13
        for k in range(14):
            if x0 <= x <= x1 and y <= y1: px[x, y] = hexc('ff5a1f') if k % 3 else hexc('ffb347')
            x += rnd.choice([-1, 0, 1]); y += 1
    cols = [hexc('ffe1b0'), hexc('ff9a5a'), hexc('ff4242'), hexc('c01628'), hexc('6e0b14')]
    for i, (dx, h, w) in enumerate([(-15, 30, 6), (15, 30, 6), (-7, 42, 8), (7, 42, 8), (0, 52, 10)]):
        flame(img, cx + dx, y1 - 14, h, w, cols, i * 7 + 1, dx / 40)
    # horns silhouette (demon crest)
    for s in (-1, 1):
        for k in range(10):
            x = cx + s * (6 + k // 2 + (k * k) // 14); y = y0 + 22 - k
            rect(img, (x, y, x + 1, y + 1), fill=hexc('1a0a12'))

def art_phantom(img, r):
    x0, y0, x1, y1 = r; cx = (x0 + x1) // 2; px = img.load(); rnd = random.Random(6)
    emblem_bg(img, r, hexc('0b0a18'), hexc('241a44'))
    for band in range(6):  # mist
        by = y0 + 12 + band * 10
        for x in range(x0, x1 + 1):
            y = by + int(2 * math.sin(x / 5 + band))
            for k in range(2):
                if y0 <= y + k <= y1: px[x, y + k] = mix(px[x, y + k], hexc('8f7ccf'), .18)
    # ghost
    gx, gy = cx, y0 + 20
    for y in range(gy - 12, gy + 30):
        for x in range(gx - 13, gx + 14):
            inside = False
            if y < gy: inside = (x - gx) ** 2 + (y - gy) ** 2 <= 13 * 13
            elif y < gy + 22: inside = abs(x - gx) <= 13
            else: inside = abs(x - gx) <= 13 and (y - gy - 22) < 4 + 3 * math.sin((x - gx) / 2.2)
            if inside and x0 <= x <= x1:
                fade = max(0, (y - gy - 8) / 26)
                px[x, y] = mix(px[x, y], hexc('ece2ff') if abs(x - gx) < 10 else hexc('b48cff'), .85 - fade * .6)
    for ex in (-5, 4):  # eyes
        rect(img, (gx + ex, gy - 2, gx + ex + 2, gy + 3), fill=hexc('1a0f33'))
        px[gx + ex + 1, gy - 1] = hexc('b48cff')
    rect(img, (gx - 2, gy + 7, gx + 1, gy + 10), fill=hexc('2a1a4d'))
    for _ in range(14): px[rnd.randint(x0, x1), rnd.randint(y0, y1)] = hexc('d8c8ff')

def art_nexus(img, r):
    x0, y0, x1, y1 = r; cx = (x0 + x1) // 2; cy = y0 + 32; px = img.load(); d = ImageDraw.Draw(img)
    emblem_bg(img, r, hexc('03110f'), hexc('0a2a2a'))
    rnd = random.Random(2)
    for _ in range(9):  # circuit traces
        x, y = rnd.randint(x0 + 2, x1 - 2), rnd.choice([y0 + 3, y1 - 3]); dirn = 1 if y < cy else -1
        pts = [(x, y)]
        for _ in range(3):
            if rnd.random() < .5: y += dirn * rnd.randint(4, 9)
            else: x += rnd.choice([-1, 1]) * rnd.randint(3, 8)
            pts.append((max(x0, min(x1, x)), y))
        d.line(pts, fill=hexc('0f5a52')); d.point(pts[-1], fill=hexc('2fe6c8'))
    def hexagon(R, col):
        pts = [(cx + R * math.cos(math.radians(60 * k + 30)), cy + R * math.sin(math.radians(60 * k + 30))) for k in range(6)]
        d.polygon(pts, outline=col)
    for R, col in ((20, hexc('0f5a52')), (16, hexc('1aa08e')), (12, hexc('2fe6c8'))):
        hexagon(R, col)
    for y in range(cy - 7, cy + 8):  # core
        for x in range(cx - 7, cx + 8):
            dd = math.hypot(x - cx, y - cy)
            if dd < 7: px[x, y] = mix(hexc('2fe6c8'), hexc('f0fffb'), max(0, 1 - dd / 5))
    for k in range(6):
        a = math.radians(60 * k + 30)
        d.line([(cx + 12 * math.cos(a), cy + 12 * math.sin(a)), (cx + 20 * math.cos(a), cy + 20 * math.sin(a))], fill=hexc('2fe6c8'))
    # base console
    rect(img, (x0 + 6, y1 - 10, x1 - 6, y1 - 4), fill=hexc('0c1f22'), outline=hexc('1aa08e'))
    for i, x in enumerate(range(x0 + 9, x1 - 8, 4)): px[x, y1 - 7] = hexc('2fe6c8') if i % 2 else hexc('ffcf4a')

CROWN = [
 "....W.......W.......W....",
 "...WYW.....WYW.....WYW...",
 "....Y.......Y.......Y....",
 "....YY.....YYY.....YY....",
 "....YYY...YYYYY...YYY....",
 "....YYYY.YYYRYYY.YYYY....",
 "....YYYYYYYRRRYYYYYYY....",
 "....YYYYYYYYRYYYYYYYY....",
 "....OOOOOOOOOOOOOOOOO....",
 "....YVYYYYYYVYYYYYYVY....",
 "....OOOOOOOOOOOOOOOOO....",
]
def art_zenith(img, r):
    x0, y0, x1, y1 = r; cx = (x0 + x1) // 2; cy = y0 + 30; px = img.load(); d = ImageDraw.Draw(img)
    emblem_bg(img, r, hexc('120a04'), hexc('2a1a3e'))
    for k in range(0, 360, 15):  # sunburst
        a = math.radians(k)
        for t in range(10, 46):
            x, y = int(cx + t * math.cos(a)), int(cy + t * math.sin(a))
            if x0 <= x <= x1 and y0 <= y <= y1: px[x, y] = mix(px[x, y], hexc('ffcf4a'), .22 * (1 - t / 46) + (.1 if k % 30 == 0 else 0))
    for R, a in ((14, .25), (10, .35)):
        for y in range(cy - R, cy + R):
            for x in range(cx - R, cx + R):
                if (x - cx) ** 2 + (y - cy) ** 2 < R * R: px[x, y] = mix(px[x, y], hexc('fff1b8'), a)
    sprite(img, cx - 25, cy - 12, CROWN, {'W': hexc('fffbe8'), 'Y': hexc('ffcf4a'), 'O': hexc('b8860b'), 'R': hexc('a855f7'), 'V': hexc('7c3aed')}, 2)
    # laurel
    for s in (-1, 1):
        for k in range(9):
            a = math.radians(200 - k * 17) if s < 0 else math.radians(-20 + k * 17)
            x, y = int(cx + 22 * math.cos(a)), int(cy + 26 + 10 * math.sin(a))
            rect(img, (x, y, x + 1, y + 1), fill=hexc('e8b830'))
    rnd = random.Random(1)
    for _ in range(18): px[rnd.randint(x0, x1), rnd.randint(y0, y1)] = hexc('fff1b8')

ART = {'blaze': art_blaze, 'astra': art_astra, 'inferno': art_inferno, 'phantom': art_phantom, 'nexus': art_nexus, 'zenith': art_zenith}

# ---------- frame styles ----------
def frame(img, r, rank, strong=False):
    acc, lit, drk = T(rank); x0, y0, x1, y1 = r; d = ImageDraw.Draw(img); px = img.load()
    if rank == 'blaze':
        bevel(img, r, acc, drk); bevel(img, (x0 + 1, y0 + 1, x1 - 1, y1 - 1), mix(drk, BG, .3), BG)
    elif rank == 'astra':
        rect(img, r, outline=mix(acc, BG, .45))
        for (x, y) in ((x0, y0), (x1, y0), (x0, y1), (x1, y1)):
            rect(img, (x - 1, y - 1, x + 1, y + 1), fill=lit)
    elif rank == 'inferno':
        rect(img, r, outline=drk); rect(img, (x0 + 1, y0 + 1, x1 - 1, y1 - 1), outline=hexc('1a0a12'))
        for x in range(x0 + 2, x1 - 1, 6): d.line([(x, y0), (x + 2, y0 - 1)], fill=acc)  # jagged teeth
        d.line([(x0, y0), (x1, y0)], fill=acc)
    elif rank == 'phantom':
        for x in range(x0, x1 + 1):
            if (x // 2) % 2 == 0: px[x, y0] = lit; px[x, y1] = mix(acc, BG, .4)
        for y in range(y0, y1 + 1):
            if (y // 2) % 2 == 0: px[x0, y] = mix(acc, BG, .2); px[x1, y] = mix(acc, BG, .4)
    elif rank == 'nexus':
        c = 3
        d.line([(x0 + c, y0), (x1 - c, y0)], fill=acc); d.line([(x0 + c, y1), (x1 - c, y1)], fill=drk)
        d.line([(x0, y0 + c), (x0, y1 - c)], fill=acc); d.line([(x1, y0 + c), (x1, y1 - c)], fill=drk)
        for (a, b) in (((x0, y0 + c), (x0 + c, y0)), ((x1 - c, y0), (x1, y0 + c)), ((x0, y1 - c), (x0 + c, y1)), ((x1 - c, y1), (x1, y1 - c))):
            d.line([a, b], fill=lit)
    elif rank == 'zenith':
        rect(img, r, outline=hexc('b8860b')); rect(img, (x0 + 1, y0 + 1, x1 - 1, y1 - 1), outline=hexc('3a2a10'))
        d.line([(x0, y0), (x1, y0)], fill=lit)
        for (x, y) in ((x0, y0), (x1, y0), (x0, y1), (x1, y1)):
            rect(img, (x - 1, y - 1, x + 1, y + 1), fill=acc); px[x, y] = WHITE

def bg_motif(img, rank):
    acc, lit, drk = T(rank); px = img.load(); rnd = random.Random(hash(rank) % 999)
    for y in range(H):
        for x in range(W):
            v = (abs(x - W / 2) / (W / 2)) ** 2 * .3 + (y / 125) ** 2 * .2
            px[x, y] = mix(hexc('0d0a15'), BG, min(.9, v))
    # violet brand haze top + rank tint bottom-left
    for y in range(0, 125):
        for x in range(W):
            dv = math.hypot((x - 120) / 90, (y - 40) / 50)
            if dv < 1: px[x, y] = mix(px[x, y], hexc('1e0f36'), (1 - dv) * .5)
            dr = math.hypot((x - 30) / 60, (y - 70) / 60)
            if dr < 1: px[x, y] = mix(px[x, y], drk, (1 - dr) * .35)
    if rank in ('astra', 'phantom'):
        for _ in range(70): px[rnd.randint(2, W - 3), rnd.randint(2, 123)] = mix(BG, lit, rnd.choice([.25, .4, .6]))
    elif rank in ('blaze', 'inferno'):
        for _ in range(45): px[rnd.randint(2, W - 3), rnd.randint(30, 123)] = mix(BG, acc, rnd.choice([.3, .5, .8]))
    elif rank == 'nexus':
        for y in range(4, 124, 6):
            for x in range(4, W - 4, 6): px[x, y] = mix(px[x, y], acc, .12)
    elif rank == 'zenith':
        for k in range(0, 360, 12):
            a = math.radians(k)
            for t in range(20, 160, 2):
                x, y = int(88 + t * math.cos(a)), int(10 + t * math.sin(a))
                if 2 <= x < W - 2 and 2 <= y < 124: px[x, y] = mix(px[x, y], acc, .08)

def glow(img, r, col, radius=4, strength=.5):
    x0, y0, x1, y1 = r; px = img.load()
    for y in range(max(0, y0 - radius), min(H, y1 + radius + 1)):
        for x in range(max(0, x0 - radius), min(W, x1 + radius + 1)):
            if x0 <= x <= x1 and y0 <= y <= y1: continue
            dd = math.hypot(max(x0 - x, 0, x - x1), max(y0 - y, 0, y - y1))
            if dd <= radius:
                a = round(strength * (1 - dd / (radius + 1)) ** 1.6 * 6) / 6
                if a > 0: px[x, y] = mix(px[x, y], col, a)

def tier_gem(img, cx, cy, rank, current):
    acc, lit, drk = T(rank); d = ImageDraw.Draw(img)
    s = 4 if current else 3
    if current: glow(img, (cx, cy, cx, cy), acc, 6, .6)
    for k in range(s + 1):
        d.line([(cx - k, cy - s + k), (cx + k, cy - s + k)], fill=lit if k < 2 else acc)
        d.line([(cx - k, cy + s - k), (cx + k, cy + s - k)], fill=drk if not current else acc)
    if not current:
        for y in range(cy - s, cy + s + 1):
            for x in range(cx - s, cx + s + 1):
                p = img.getpixel((x, y))
                if p != img.getpixel((0, 0)): pass
        desat_box = (cx - s, cy - s, cx + s, cy + s)
        desat(img, desat_box, .35, .7)

def build(rank):
    acc, lit, drk = T(rank); D = DATA[rank]
    img = Image.new('RGBA', (W, H), BG); bg_motif(img, rank); d = ImageDraw.Draw(img); px = img.load()
    rect(img, (0, 0, W - 1, H - 1), outline=VIOD); rect(img, (1, 1, W - 2, H - 2), outline=hexc('17112a'))
    for (x, y) in [(0, 0), (W - 1, 0), (0, H - 1), (W - 1, H - 1)]: px[x, y] = (0, 0, 0, 0)
    # ===== header =====
    b = badge(rank); bx, by = 9, 6
    glow(img, (bx, by, bx + b.width - 1, by + b.height - 1), acc, 4, .35)
    img.alpha_composite(b.resize((b.width, b.height)), (bx, by))
    text(img, 9, 24, THEME[rank]['tag'], mix(acc, WHITE, .35))
    # price plate (slots 6-8 + title zone)
    pr = (114, 4, 168, 32)
    vgrad(img, pr, hexc('1c1433'), hexc('100b1d')); frame(img, pr, rank)
    text_c(img, (pr[0] + pr[2]) // 2, 7, 'ЦЕНА', DIM)
    ps = f'{D["price"]}₽'
    text_c(img, (pr[0] + pr[2]) // 2 + 1, 16, ps, lit if rank != 'zenith' else hexc('fff1b8'), scale=2, shadow=drk)
    # ===== emblem panel cols 0-2, rows 1-4 =====
    er = (8, 36, 59, 105)
    glow(img, er, acc, 4, .35 if rank != 'zenith' else .5)
    ART[rank](img, (er[0] + 2, er[1] + 2, er[2] - 2, er[3] - 2))
    frame(img, er, rank, True); frame(img, (er[0] + 1, er[1] + 1, er[2] - 1, er[3] - 1), rank) if rank == 'zenith' else None
    # ===== stat bars cols 3-8, rows 1-4 =====
    prev = DATA[TIERS[TIERS.index(rank) - 1]]
    rows = [('auc', 'АУКЦИОН', D['auc'], D['auc'] - prev['auc']),
            ('prv', 'ПРИВАТЫ', D['prv'], D['prv'] - prev['prv']),
            ('home', 'ДОМА', D['home'], D['home'] - prev['home']),
            ('cmd', 'НОВОЕ', D['cmd'], None)]
    for i, (k, label, val, delta) in enumerate(rows):
        x0, y0, x1, y1 = area(3, 1 + i, 8, 1 + i); r = (x0 + 2, y0 + 1, x1 - 1, y1 - 1)
        vgrad(img, r, mix(PANEL2, drk, .25), PANEL)
        frame(img, r, rank)
        ic(img, r[0] + 4, r[1] + 3, k, acc)
        text(img, r[0] + 18, r[1] + 5, label, DIM)
        if k == 'cmd':
            text(img, r[2] - 4 - text_w(val), r[1] + 4, val, lit)
        elif (rank, k) in UNRESOLVED:
            vx = r[2] - 4 - text_w('?', 2)
            text(img, vx, r[1] + 1, '?', mix(acc, BG, .25), scale=2, shadow=drk)
        else:
            vs = str(val); vx = r[2] - 4 - text_w(vs, 2)
            text(img, vx, r[1] + 1, vs, lit, scale=2, shadow=drk)
            ds = f'+{delta}'
            prev_rank = TIERS[TIERS.index(rank) - 1]
            if delta and (prev_rank, k) not in UNRESOLVED and vx - 4 - text_w(ds) > r[0] + 18 + text_w(label) + 3:
                text(img, vx - 4 - text_w(ds), r[1] + 5, ds, mix(acc, BG, .25))
    # ===== footer row 5: back, tier ladder, close =====
    d.line([(26, 125), (149, 125)], fill=LINE)
    x, y = slot_xy(45); r = (x + 1, y + 1, x + 16, y + 16)
    vgrad(img, r, hexc('231a3a'), hexc('150f24')); bevel(img, r, LINE2, hexc('07060b')); arrow_left(img, x + 5, y + 6, hexc('d8b8ff'))
    x, y = slot_xy(53); r = (x + 1, y + 1, x + 16, y + 16)
    vgrad(img, r, hexc('231a3a'), hexc('150f24')); bevel(img, r, hexc('7a3a52'), hexc('07060b')); cross(img, x + 6, y + 6, hexc('ff6b81'))
    d.line([(34, slot_xy(46)[1] + 9), (141, slot_xy(46)[1] + 9)], fill=LINE2)
    for i, t in enumerate(TIERS):
        x, y = slot_xy(46 + i); cx, cy = x + 9, y + 9
        if t == rank:
            rr = (x + 1, y + 1, x + 16, y + 16); vgrad(img, rr, mix(PANEL2, T(t)[2], .5), PANEL); rect(img, rr, outline=T(t)[0])
        tier_gem(img, cx, cy, t, t == rank)
    # ===== player inventory zone =====
    rect(img, (2, 126, W - 3, H - 3), fill=hexc('0c0914')); d.line([(7, 126), (168, 126)], fill=LINE)
    player_inv(img, BG, hexc('120e1c'), LINE2, hexc('050408'))
    if rank == 'zenith':  # legendary: gold double outer frame with gem corners
        rect(img, (0, 0, W - 1, H - 1), outline=hexc('b8860b')); rect(img, (1, 1, W - 2, H - 2), outline=hexc('ffcf4a'))
        rect(img, (2, 2, W - 3, H - 3), outline=hexc('5a3f0a'))
        for (x, y) in [(2, 2), (W - 3, 2), (2, H - 3), (W - 3, H - 3)]:
            rect(img, (x - 1, y - 1, x + 1, y + 1), fill=hexc('a855f7')); px[x, y] = WHITE
        for (x, y) in [(0, 0), (W - 1, 0), (0, H - 1), (W - 1, H - 1)]: px[x, y] = (0, 0, 0, 0)
    return img

NAMES = {'blaze': 'BLAZE', 'astra': 'ASTRA', 'inferno': 'INFERNO', 'phantom': 'PHANTOM', 'nexus': 'NEXUS', 'zenith': 'ZENITH'}

if __name__ == '__main__':
    import os
    from PIL import ImageFont
    out = '/home/claude/zx_report/ranks'; os.makedirs(out + '/native', exist_ok=True)
    F = '/usr/share/fonts/opentype/inter/Inter-%s.otf'
    def font(sz, w='SemiBold'): return ImageFont.truetype(F % w, sz)
    tiles = []
    for rk in ['blaze', 'astra', 'inferno', 'phantom', 'nexus', 'zenith']:
        g = build(rk); g.save(f'{out}/native/rank_{rk}_menu_176x222.png')
        S = 3; big = g.resize((W * S, H * S), Image.NEAREST)
        ImageDraw.Draw(big).text((8 * S, 128 * S - 3), 'Inventory', font=font(7 * S - 4, 'Regular'), fill=(64, 64, 64, 255))
        tiles.append((rk, big))
        # individual sheet
        c = Image.new('RGBA', (big.width + 80, big.height + 130), (16, 13, 24, 255)); c.alpha_composite(big, (40, 100))
        dd = ImageDraw.Draw(c); dd.text((40, 26), f'{NAMES[rk]} — меню привилегии', font=font(34, 'Bold'), fill=(244, 239, 255))
        dd.text((40, 68), f'{THEME[rk]["tag"].capitalize()} · {DATA[rk]["price"]} ₽ · макет 1:1 (×3)', font=font(18, 'Medium'), fill=(170, 160, 200))
        c.save(f'{out}/ZENTROX_RANK_{NAMES[rk]}.png')
    # overview 3x2
    tw, th = tiles[0][1].width, tiles[0][1].height
    ov = Image.new('RGBA', (3 * tw + 4 * 30, 2 * (th + 50) + 140), (16, 13, 24, 255)); dd = ImageDraw.Draw(ov)
    dd.text((30, 30), 'ZENTROX — меню донатных привилегий (макеты 1:1, ×3)', font=font(40, 'Bold'), fill=(244, 239, 255))
    dd.text((30, 84), 'Единая сетка слотов и стиль ZENTROX · у каждого ранга своя тема, рамки и эмблема · покупка не подключена', font=font(20, 'Medium'), fill=(170, 160, 200))
    for i, (rk, big) in enumerate(tiles):
        x = 30 + (i % 3) * (tw + 30); y = 140 + (i // 3) * (th + 50)
        dd.text((x, y), NAMES[rk], font=font(24, 'Bold'), fill=(220, 210, 245)); ov.alpha_composite(big, (x, y + 36))
    ov.save(f'{out}/ZENTROX_RANKS_OVERVIEW.png')
    print('ok')
