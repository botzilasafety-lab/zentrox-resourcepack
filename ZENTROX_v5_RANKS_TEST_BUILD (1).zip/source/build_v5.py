"""ZENTROX v5: ресурспак (v4 + 24 фона) и 24 YAML DeluxeMenus 1.14.1 для системы рангов.
Ничего из существующего не меняет: добавляет файлы и провайдеры шрифта."""
import json, os, shutil, hashlib, zipfile, sys
sys.path.insert(0, '/home/claude/concepts')
import ranks, roles, all20, categories
from pix import slots_in

V4_DIR = '/home/claude/zx_out/pack'
OUT = '/home/claude/zx_v5'
PACK = f'{OUT}/pack'
TEX = 'zentrox:font/zxr/'
BLANK = 'zentrox:gui_b/blank'
SHIFT = ''

ORDER = all20.ORDER
WEIGHT = all20.WEIGHT; CAT = all20.CATEGORY; label = all20.label
MENUS = ['hub', 'cat_players', 'cat_donate', 'cat_staff'] + ORDER          # 24
CODE = {m: chr(0xE113 + i) for i, m in enumerate(MENUS)}                    # U+E113 … U+E12A
NAME = {m: f'zxr_{m}' for m in MENUS}                                       # внутренние имена DeluxeMenus
PARENT = {'cat_players': 'hub', 'cat_donate': 'hub', 'cat_staff': 'hub',
          **{g: {'players': 'cat_players', 'donate': 'cat_donate', 'staff': 'cat_staff'}[CAT[g]] for g in ORDER}}
BRANCH_RU = {'admin': 'Администрация', 'moder': 'Модерация', 'help': 'Помощники и строители'}

# ---------- 1. ресурспак ----------
shutil.rmtree(OUT, ignore_errors=True); shutil.copytree(V4_DIR, PACK)
os.makedirs(f'{PACK}/assets/zentrox/textures/font/zxr', exist_ok=True)
BUILDERS = {'hub': roles.build_hub, 'cat_players': categories.build_players, 'cat_donate': categories.build_donates,
            'cat_staff': categories.build_staff}
ZONES = {}
for m in MENUS:
    img, zones = (BUILDERS[m]() if m in BUILDERS else all20.build(m))
    assert img.size == (176, 222)
    img.save(f'{PACK}/assets/zentrox/textures/font/zxr/{m}.png'); ZONES[m] = zones
fp = f'{PACK}/assets/minecraft/font/default.json'
font = json.load(open(fp, encoding='utf-8'))
used = {c for p in font['providers'] for c in ''.join(p.get('chars', []))} | {c for p in font['providers'] for c in p.get('advances', {})}
assert not (set(CODE.values()) & used)
idx = next(i for i, p in enumerate(font['providers']) if p.get('file') == 'zentrox:font/gui_modes_b.png') + 1
for k, m in enumerate(MENUS):
    font['providers'].insert(idx + k, {"type": "bitmap", "file": f"{TEX}{m}.png", "ascent": 13, "height": 222, "chars": [CODE[m]]})
json.dump(font, open(fp, 'w', encoding='utf-8'), indent=2, ensure_ascii=False)
PLATE = {p['file'].split('/')[-1][5:-4]: p['chars'][0] for p in font['providers'] if p.get('file', '').startswith('zentrox:font/rank_')}

# ---------- 2. YAML ----------
def q(s):
    out = []
    for ch in s:
        if ch == '\\': out.append('\\\\')
        elif ch == '"': out.append('\\"')
        elif 0xE000 <= ord(ch) <= 0xF8FF: out.append('\\u%04X' % ord(ch))
        else: out.append(ch)
    return '"' + ''.join(out) + '"'

def item(key, slots, name, lore=(), click=None, priority=None, req=None):
    return dict(key=key, slots=sorted(slots), name=name, lore=list(lore), click=click, priority=priority, req=req)

def open_(m): return [f'[openguimenu] {NAME[m]}']
CLOSE = ['[close]']
NOT_LINKED = ['[message] &5ZENTROX &8» &7Покупки пока не подключены.']

def nav(m):
    back = item('back', [45], '&d&lНАЗАД', ['&7Вернуться на предыдущий уровень.'] if m != 'hub' else ['&7Закрыть меню рангов.'],
                CLOSE if m == 'hub' else open_(PARENT[m]))
    close = item('close', [53], '&c&lЗАКРЫТЬ', ['&7Закрыть меню.'], CLOSE)
    return [back, close]

def plate(g): return '&f' + PLATE[g]

def menu_hub():
    z = ZONES['hub']; its = [
        item('cat_players', z['Категория: Игроки'], '&f&lИГРОКИ И СПЕЦ-ГРУППЫ', ['&7PLAYER, TESTER, YOUTUBE', '', '&d▶ Открыть'], open_('cat_players')),
        item('cat_donate', z['Категория: Донаты'], '&e&lДОНАТНЫЕ ПРИВИЛЕГИИ', ['&7BLAZE … ZENITH', '&8Покупки пока не подключены.', '', '&d▶ Открыть'], open_('cat_donate')),
        item('cat_staff', z['Категория: Персонал'], '&d&lКОМАНДА ZENTROX', ['&7Администрация, модерация,', '&7помощники и строители', '', '&d▶ Открыть'], open_('cat_staff'))]
    for i, g in enumerate(ORDER, 1):   # «Твой ранг»: старшая группа побеждает (priority 1 = высший)
        req = None if g == 'default' else g
        its.append(item(f'your_rank_{g}', z['Твой ранг'], '&d&lТВОЙ РАНГ',
                        [plate(g), '&7Все группы: &f%luckperms_groups%', '', '&d▶ Открыть меню ранга'], open_(g), priority=i, req=req))
    return its + nav('hub')

def menu_cat_players():
    z = ZONES['cat_players']; its = []
    for g in ['youtube', 'tester', 'default']:
        its.append(item(g, z[label(g) + ' → меню группы'], '&f&l' + label(g), [plate(g), f'&7Вес: &f{WEIGHT[g]}', '', '&d▶ Открыть'], open_(g)))
    return its + nav('cat_players')

def menu_cat_donate():
    z = ZONES['cat_donate']; its = []
    for g in ['blaze', 'astra', 'inferno', 'phantom', 'nexus', 'zenith']:
        its.append(item(g, z[label(g) + ' → меню'], '&f&l' + label(g), [plate(g), f'&7Цена: &f{ranks.DATA[g]["price"]} ₽', '&8Покупки пока не подключены.', '', '&d▶ Подробнее'], open_(g)))
    return its + nav('cat_donate')

def menu_cat_staff():
    z = ZONES['cat_staff']; its = []
    for br, gs in all20.BRANCH.items():
        for i, g in enumerate(gs):
            its.append(item(g, z[label(g) + ' → меню'], '&f&l' + label(g),
                            [plate(g), f'&7Ветка: &f{BRANCH_RU[br]}', f'&7Вес: &f{WEIGHT[g]}', '', '&d▶ Открыть'], open_(g)))
    return its + nav('cat_staff')

def lim(g, k, ru):
    if (g, k) in ranks.UNRESOLVED: return f'&7{ru}: &eна согласовании'
    return f'&7{ru}: &f{ranks.DATA[g][k]}'

def menu_donate(g):
    D = ranks.DATA[g]; tag = ranks.THEME[g]['tag'].capitalize()
    its = [item('price', [6, 7, 8], f'&f&lЦЕНА: {D["price"]} ₽', ['&8Покупки пока не подключены.'], NOT_LINKED),
           item('emblem', slots_in(0, 1, 2, 4), '&f&l' + label(g), [plate(g), f'&7{tag}', f'&7Вес: &f{WEIGHT[g]}', '', '&8Значения — проект, уточняются.']),
           item('auction', slots_in(3, 1, 8, 1), '&f&lАУКЦИОН', [lim(g, 'auc', 'Лотов на аукционе'), '&8Проект, уточняется.']),
           item('claims', slots_in(3, 2, 8, 2), '&f&lПРИВАТЫ', [lim(g, 'prv', 'Приватов'), '&8Проект, уточняется.']),
           item('homes', slots_in(3, 3, 8, 3), '&f&lДОМА', [lim(g, 'home', 'Точек дома'), '&8Проект, уточняется.']),
           item('command', slots_in(3, 4, 8, 4), '&f&lНОВАЯ КОМАНДА', [f'&7План: &f{D["cmd"]}', '&8Права не выдаются через это меню.'])]
    for i, t in enumerate(ranks.TIERS):     # 46..52 лестница
        tg = 'default' if t == 'player' else t
        if tg == g:
            its.append(item(f'ladder_{tg}', [46 + i], '&f&l' + label(tg), [plate(tg), '&7Ты смотришь этот ранг.']))
        else:
            its.append(item(f'ladder_{tg}', [46 + i], '&f&l' + label(tg), [plate(tg), '', '&d▶ Открыть'], open_(tg)))
    return its + nav(g)

def menu_staff(g):
    br = all20.branch_of(g); gs = all20.BRANCH[br]
    its = [item('weight', [6, 7, 8], f'&f&lВЕС: {WEIGHT[g]}', ['&7Положение в иерархии LuckPerms.']),
           item('emblem', slots_in(0, 1, 2, 4), '&f&l' + label(g),
                [plate(g), f'&7Роль: &f{ranks.THEME[g]["tag"].capitalize()}', f'&7Ветка: &f{BRANCH_RU[br]}', f'&7Место в ветке: &f{gs.index(g) + 1} из {len(gs)}',
                 '', '&8Права группы здесь не показываются.'])]
    for i, b in enumerate(gs):
        if b == g:
            its.append(item(f'branch_{b}', slots_in(3, 1 + i, 8, 1 + i), '&f&l' + label(b), [plate(b), f'&7Вес: &f{WEIGHT[b]}', '&7Ты смотришь эту группу.']))
        else:
            its.append(item(f'branch_{b}', slots_in(3, 1 + i, 8, 1 + i), '&f&l' + label(b), [plate(b), f'&7Вес: &f{WEIGHT[b]}', '', '&d▶ Открыть'], open_(b)))
    if len(gs) == 3:
        its.append(item('role_info', slots_in(3, 4, 8, 4), '&f&lОПИСАНИЕ РОЛИ', ['&7Описание скоро появится.']))
    return its + nav(g)

def menu_special(g):
    role = {'youtube': 'Автор контента', 'tester': 'Тестировщик'}[g]
    its = [item('weight', [6, 7, 8], f'&f&lВЕС: {WEIGHT[g]}', ['&7Положение в иерархии LuckPerms.']),
           item('emblem', slots_in(0, 1, 2, 4), '&f&l' + label(g), [plate(g), f'&7Роль: &f{role}', '', '&8Возможности группы здесь не указываются.']),
           item('role', slots_in(3, 1, 8, 2), '&f&lРОЛЬ', [f'&f{role}']),
           item('conditions', slots_in(3, 3, 8, 3), '&f&lУСЛОВИЯ ПОЛУЧЕНИЯ', ['&7Пока не опубликованы.']),
           item('contact', slots_in(3, 4, 8, 4), '&f&lСВЯЗЬ', ['&7Пока не опубликована.'])]
    return its + nav(g)

def menu_default():
    D = ranks.DATA['player']
    its = [item('price', [6, 7, 8], '&f&lБЕСПЛАТНО', ['&7Базовый ранг каждого игрока.']),
           item('emblem', slots_in(0, 1, 2, 4), '&f&lPLAYER', [plate('default'), '&7Базовый ранг', f'&7Вес: &f{WEIGHT["default"]}', '', '&8Значения — проект, уточняются.']),
           item('auction', slots_in(3, 1, 8, 1), '&f&lАУКЦИОН', [f'&7Лотов на аукционе: &f{D["auc"]}', '&8Проект, уточняется.']),
           item('claims', slots_in(3, 2, 8, 2), '&f&lПРИВАТЫ', [f'&7Приватов: &f{D["prv"]}', '&8Проект, уточняется.']),
           item('homes', slots_in(3, 3, 8, 3), '&f&lДОМА', [f'&7Точек дома: &f{D["home"]}', '&8Проект, уточняется.']),
           item('upgrade', slots_in(3, 4, 8, 4), '&d&lУЛУЧШИТЬ РАНГ', ['&7Открыть донатные привилегии.', '&8Покупки пока не подключены.', '', '&d▶ Открыть'], open_('cat_donate'))]
    return its + nav('default')

def spec(m):
    if m == 'hub': return menu_hub()
    if m == 'cat_players': return menu_cat_players()
    if m == 'cat_donate': return menu_cat_donate()
    if m == 'cat_staff': return menu_cat_staff()
    if m == 'default': return menu_default()
    if m in ('youtube', 'tester'): return menu_special(m)
    if CAT[m] == 'donate': return menu_donate(m)
    return menu_staff(m)

TITLE_RU = {'hub': 'хаб /zentroxranks', 'cat_players': 'категория «Игроки и спец-группы»', 'cat_donate': 'категория «Донатные привилегии»',
            'cat_staff': 'категория «Команда ZENTROX»'}
SPECS = {}
os.makedirs(f'{OUT}/gui_menus', exist_ok=True)
for m in MENUS:
    its = spec(m); SPECS[m] = its
    L = [f'# ZENTROX v5 — {TITLE_RU.get(m, "группа " + label(m))} | DeluxeMenus 1.14.1 | Paper 1.21.11',
         f'# Внутреннее имя: {NAME[m]}. Фон — символ U+{ord(CODE[m]):04X} из ресурспака v5. Покупки не подключены, права не выдаются.',
         f'menu_title: "&f\\uE110\\u{ord(CODE[m]):04X}"']
    if m == 'hub': L += ['open_command: zentroxranks', 'register_command: true']
    L += ['size: 54', 'items:']
    for it in its:
        L += [f'  {it["key"]}:', '    material: PAPER', f'    item_model: {BLANK}', f'    slots: [{", ".join(map(str, it["slots"]))}]']
        if it['priority'] is not None: L.append(f'    priority: {it["priority"]}')
        if it['req']:
            L += ['    view_requirement:', '      requirements:', f'        in_{it["req"]}:', '          type: string equals ignorecase',
                  f'          input: "%luckperms_inherits_group_{it["req"]}%"', '          output: "yes"']
        L.append(f'    display_name: {q(it["name"])}')
        if it['lore']: L += ['    lore:'] + [f'      - {q(x)}' for x in it['lore']]
        if it['click']: L += ['    click_commands:'] + [f'      - {q(c)}' for c in it['click']]
    open(f'{OUT}/gui_menus/{NAME[m]}.yml', 'w', encoding='utf-8').write('\n'.join(L) + '\n')

# записи для config.yml (только добавить внутрь существующего gui_menus:)
G = ['# ZENTROX v5 — ДОБАВИТЬ внутрь существующего блока gui_menus: в plugins/DeluxeMenus/config.yml',
     '# Существующие записи (zentrox_ranks, servers и др.) НЕ трогать. Отступ — как у соседних записей (2 пробела).']
for m in MENUS: G += [f'  {NAME[m]}:', f'    file: {NAME[m]}.yml']
open(f'{OUT}/GUI_MENUS_ADD.yml', 'w', encoding='utf-8').write('\n'.join(G) + '\n')

# ZIP пака
zp = f'{OUT}/ZENTROX_RESOURCEPACK_v5_RANKS_1.21.11.zip'
with zipfile.ZipFile(zp, 'w', zipfile.ZIP_DEFLATED) as zf:
    for root, _, files in sorted(os.walk(PACK)):
        for f in sorted(files):
            full = os.path.join(root, f); zf.write(full, os.path.relpath(full, PACK))
sha1 = hashlib.sha1(open(zp, 'rb').read()).hexdigest(); open(f'{OUT}/SHA1.txt', 'w').write(sha1 + '\n')
json.dump({'codes': {NAME[m]: 'U+%04X' % ord(CODE[m]) for m in MENUS}, 'parent': {NAME[m]: NAME[p] for m, p in PARENT.items()},
           'zones': {m: {k: v for k, v in z.items()} for m, z in ZONES.items()}}, open(f'{OUT}/build_manifest.json', 'w', encoding='utf-8'), ensure_ascii=False, indent=1)
print('ok', len(MENUS), 'menus', sha1)
